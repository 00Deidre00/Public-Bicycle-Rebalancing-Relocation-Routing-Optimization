
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Modal,
  Linking,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import RouteMapView from '@/components/RouteMapView';
import ConsoleDisplay from '@/components/ConsoleDisplay';
import { RouteStep } from '@/types/RouteData';
import { fetchAndParseCSV, CSVRow } from '@/utils/csvParser';
import * as Network from 'expo-network';

interface PathResult {
  redistributionAmount: number;
  route: string[];
  totalDistance: number;
  estimatedTime: number;
  routeSteps: RouteStep[];
}

interface LogEntry {
  timestamp: string;
  type: 'log' | 'warn' | 'error' | 'info';
  message: string;
}

export default function HomeScreen() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [isCalculating, setIsCalculating] = useState(false);
  const [result, setResult] = useState<PathResult | null>(null);
  const [showMap, setShowMap] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);

  // CSV URL from Google Cloud Storage
  const CSV_URL = 'https://storage.googleapis.com/output_20251025/final_rebalancing_plan.csv';

  // Custom console methods that also display on screen
  const addLog = (type: 'log' | 'warn' | 'error' | 'info', ...args: any[]) => {
    const timestamp = new Date().toLocaleTimeString('ko-KR', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit',
      fractionalSecondDigits: 3
    });
    
    const message = args.map(arg => {
      if (typeof arg === 'object') {
        try {
          return JSON.stringify(arg, null, 2);
        } catch (e) {
          return String(arg);
        }
      }
      return String(arg);
    }).join(' ');

    setLogs(prevLogs => [...prevLogs, { timestamp, type, message }]);

    // Also log to actual console
    switch (type) {
      case 'error':
        console.error(...args);
        break;
      case 'warn':
        console.warn(...args);
        break;
      case 'info':
        console.info(...args);
        break;
      default:
        console.log(...args);
    }
  };

  const clearLogs = () => {
    setLogs([]);
    addLog('info', '로그가 지워졌습니다');
  };

  // Open URL in browser for testing
  const openURLInBrowser = async () => {
    try {
      const supported = await Linking.canOpenURL(CSV_URL);
      if (supported) {
        await Linking.openURL(CSV_URL);
      } else {
        Alert.alert('오류', 'URL을 열 수 없습니다.');
      }
    } catch (error) {
      Alert.alert('오류', 'URL을 여는 중 오류가 발생했습니다.');
    }
  };

  // Check network status
  const checkNetworkStatus = async () => {
    try {
      addLog('info', '네트워크 상태 확인 중...');
      const networkState = await Network.getNetworkStateAsync();
      
      addLog('info', '네트워크 연결됨:', networkState.isConnected);
      addLog('info', '인터넷 접근 가능:', networkState.isInternetReachable);
      addLog('info', '연결 타입:', networkState.type);
      
      const info = `
네트워크 상태:
- 연결됨: ${networkState.isConnected ? '예' : '아니오'}
- 인터넷 접근 가능: ${networkState.isInternetReachable ? '예' : networkState.isInternetReachable === false ? '아니오' : '알 수 없음'}
- 연결 타입: ${networkState.type}
      `.trim();
      
      Alert.alert('네트워크 상태', info, [{ text: '확인' }]);
    } catch (error) {
      const errorInfo = `오류: ${error instanceof Error ? error.message : String(error)}`;
      addLog('error', '네트워크 상태 확인 실패:', errorInfo);
      Alert.alert('네트워크 상태 확인 실패', errorInfo, [{ text: '확인' }]);
    }
  };

  // Show help dialog with detailed instructions
  const showHelpDialog = () => {
    Alert.alert(
      '📋 CSV 파일 공개 설정 방법',
      `Google Cloud Storage 파일을 공개로 설정하는 방법:\n\n` +
      `1️⃣ Google Cloud Console 접속\n` +
      `   (console.cloud.google.com)\n\n` +
      `2️⃣ Storage → 버킷 선택\n\n` +
      `3️⃣ 파일 찾기 (final_rebalancing_plan.csv)\n\n` +
      `4️⃣ 파일 클릭 → "권한" 탭 선택\n\n` +
      `5️⃣ "액세스 권한 추가" 버튼 클릭\n\n` +
      `6️⃣ 다음 정보 입력:\n` +
      `   • 주 구성원: allUsers\n` +
      `   • 역할: Storage 객체 뷰어\n\n` +
      `7️⃣ "저장" 클릭\n\n` +
      `8️⃣ 앱으로 돌아와서 "경로 찾기" 재시도\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `💡 확인 방법:\n` +
      `브라우저에서 URL을 열었을 때 파일이 바로 다운로드되면 성공입니다!`,
      [
        { text: '확인' },
        { text: '브라우저에서 테스트', onPress: openURLInBrowser }
      ]
    );
  };

  // Test CSV connection
  const testCSVConnection = async () => {
    addLog('info', '========================================');
    addLog('info', 'CSV 연결 테스트 시작');
    addLog('info', '========================================');
    addLog('info', 'CSV URL:', CSV_URL);
    
    setIsCalculating(true);
    
    try {
      // First check network
      addLog('info', '1단계: 네트워크 상태 확인');
      const networkState = await Network.getNetworkStateAsync();
      addLog('info', '네트워크 연결됨:', networkState.isConnected);
      addLog('info', '인터넷 접근 가능:', networkState.isInternetReachable);
      addLog('info', '연결 타입:', networkState.type);
      
      if (!networkState.isConnected) {
        addLog('error', '인터넷에 연결되어 있지 않습니다');
        Alert.alert(
          '네트워크 오류',
          '인터넷에 연결되어 있지 않습니다.\n\nWi-Fi 또는 모바일 데이터를 확인해주세요.',
          [{ text: '확인' }]
        );
        return;
      }
      
      addLog('info', '2단계: CSV 파일 연결 테스트');
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        addLog('warn', '요청 시간 초과 (10초)');
        controller.abort();
      }, 10000);
      
      const response = await fetch(CSV_URL, {
        method: 'HEAD',
        headers: {
          'Accept': 'text/csv, text/plain, */*',
        },
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);
      
      addLog('info', 'HTTP 상태:', response.status, response.statusText);
      addLog('info', 'URL:', response.url);
      addLog('info', '응답 타입:', response.type);
      addLog('info', '응답 OK:', response.ok);
      
      addLog('info', '응답 헤더:');
      response.headers.forEach((value, key) => {
        addLog('info', `  ${key}: ${value}`);
      });
      
      if (response.ok) {
        addLog('info', '✅ CSV 연결 성공!');
        Alert.alert(
          '✅ CSV 연결 성공',
          `파일에 접근할 수 있습니다.\n\n상태: ${response.status}\n\n경로 찾기 버튼을 눌러 데이터를 불러오세요.`,
          [
            { text: '확인' },
            { text: '브라우저에서 열기', onPress: openURLInBrowser }
          ]
        );
      } else {
        addLog('error', 'CSV 연결 실패 - HTTP', response.status);
        Alert.alert(
          '❌ CSV 연결 실패',
          `HTTP 오류: ${response.status}\n\n파일이 공개 접근 가능한지 확인해주세요.`,
          [
            { text: '확인' },
            { text: '설정 방법 보기', onPress: showHelpDialog },
            { text: '브라우저에서 열기', onPress: openURLInBrowser }
          ]
        );
      }
    } catch (error: any) {
      addLog('error', '연결 테스트 실패');
      addLog('error', '오류 타입:', error.name || 'Unknown');
      addLog('error', '오류 메시지:', error.message || String(error));
      
      if (error.name === 'AbortError') {
        addLog('error', '요청 시간 초과 (10초)');
      } else if (error.message.includes('Network request failed')) {
        addLog('error', '네트워크 요청 실패');
      } else if (error.message.includes('Failed to fetch')) {
        addLog('error', 'CSV 파일을 가져올 수 없습니다');
      }
      
      Alert.alert(
        '❌ CSV 연결 실패',
        `오류: ${error.message || String(error)}`,
        [
          { text: '확인' },
          { text: '설정 방법 보기', onPress: showHelpDialog },
          { text: '네트워크 확인', onPress: checkNetworkStatus },
          { text: '브라우저에서 열기', onPress: openURLInBrowser }
        ]
      );
    } finally {
      setIsCalculating(false);
      addLog('info', '========================================');
      addLog('info', 'CSV 연결 테스트 완료');
      addLog('info', '========================================');
    }
  };

  // Convert CSV row to RouteStep with flexible column name matching
  const csvRowToRouteStep = (row: CSVRow, rowIndex: number): RouteStep | null => {
    try {
      addLog('log', `행 ${rowIndex} 처리 중...`);
      
      // Helper function to find column value by multiple possible names
      const findValue = (possibleNames: string[]): string => {
        for (const name of possibleNames) {
          if (row[name] !== undefined && row[name] !== null && row[name] !== '') {
            return row[name];
          }
        }
        return '';
      };
      
      // Extract Step from the first column
      const stepValue = findValue([
        'Step', 'step', 'STEP', '단계', '스텝', 'Order', 'order', 'Sequence', 'sequence'
      ]);
      const step = stepValue ? parseInt(stepValue) : rowIndex + 1;
      
      // Extract ClusterID
      const clusterId = findValue([
        '클러스터ID', 'ClusterID', 'cluster_id', 'Cluster', '클러스터', 
        'ClusterId', 'cluster', 'CLUSTER_ID', 'CLUSTERID'
      ]).trim() || 'Unknown';
      
      // Extract StationID
      const stationId = findValue([
        '대여소ID', 'StationID', 'station_id', 'Station', '대여소 ID', 
        '정류장ID', 'StationId', 'station', 'STATION_ID', 'STATIONID'
      ]).trim() || 'Unknown';
      
      // Extract Latitude
      const latValue = findValue([
        '위도', 'Latitude', 'latitude', 'lat', 'LAT', 'Lat', 'LATITUDE'
      ]);
      const latitude = parseFloat(latValue);
      
      // Extract Longitude
      const lngValue = findValue([
        '경도', 'Longitude', 'longitude', 'lng', 'lon', 'LNG', 'LON', 'Lng', 'Lon', 'LONGITUDE'
      ]);
      const longitude = parseFloat(lngValue);
      
      // Extract ActionAmount
      const actionValue = findValue([
        '작업량(d)', '작업량', 'ActionAmount', 'action_amount', 'Action', 
        '작업', 'Workload', 'workload', 'ACTION_AMOUNT', 'ACTIONAMOUNT'
      ]);
      const actionAmount = actionValue ? parseInt(actionValue) : 0;
      
      // Extract TruckLoad_Before
      const beforeValue = findValue([
        '트럭재고(q_before)', '트럭재고', 'TruckLoad_Before', 'truck_load_before', 
        'LoadBefore', '적재량', 'TRUCK_LOAD_BEFORE', 'TRUCKLOAD_BEFORE'
      ]);
      const truckLoadBefore = beforeValue ? parseInt(beforeValue) : 0;
      
      // Extract TruckLoad_After
      const afterValue = findValue([
        '트럭재고(q_after)', 'TruckLoad_After', 'truck_load_after', 
        'LoadAfter', '트럭재고(작업후)', 'TRUCK_LOAD_AFTER', 'TRUCKLOAD_AFTER'
      ]);
      const truckLoadAfter = afterValue ? parseInt(afterValue) : 0;

      // Validate required fields
      if (isNaN(latitude) || isNaN(longitude)) {
        addLog('warn', `행 ${rowIndex}: 잘못된 좌표 (NaN) - 위도: ${latitude}, 경도: ${longitude}`);
        return null;
      }
      
      if (latitude === 0 && longitude === 0) {
        addLog('warn', `행 ${rowIndex}: 좌표가 0입니다`);
        return null;
      }

      // Check if coordinates are in valid range
      if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
        addLog('warn', `행 ${rowIndex}: 좌표 범위 초과 - 위도: ${latitude}, 경도: ${longitude}`);
        return null;
      }

      const routeStep: RouteStep = {
        Step: step,
        ClusterID: clusterId,
        StationID: stationId,
        Latitude: latitude,
        Longitude: longitude,
        ActionAmount: actionAmount,
        TruckLoad_Before: truckLoadBefore,
        TruckLoad_After: truckLoadAfter,
      };

      addLog('log', `✓ 행 ${rowIndex} 파싱 성공: ${stationId}`);
      return routeStep;
    } catch (error) {
      addLog('error', `✗ 행 ${rowIndex} 변환 오류:`, error);
      return null;
    }
  };

  // Calculate optimal path by fetching CSV data
  const calculateOptimalPath = async () => {
    addLog('info', '========================================');
    addLog('info', '경로 계산 시작');
    addLog('info', '========================================');
    addLog('info', '시간:', new Date().toISOString());
    addLog('info', 'CSV URL:', CSV_URL);
    
    setIsCalculating(true);
    
    try {
      addLog('info', '1단계: CSV 데이터 가져오기');
      
      // Fetch and parse CSV data
      const csvData = await fetchAndParseCSV(CSV_URL);
      
      addLog('info', '✓ CSV 데이터 가져오기 성공');
      addLog('info', '총 CSV 행 수:', csvData.length);
      
      if (csvData.length === 0) {
        throw new Error('CSV 파일이 비어있습니다');
      }

      addLog('info', '2단계: CSV 구조 분석');
      addLog('info', '첫 번째 행 샘플:', JSON.stringify(csvData[0]));
      addLog('info', '열 헤더:', Object.keys(csvData[0]).join(', '));
      addLog('info', '총 열 수:', Object.keys(csvData[0]).length);
      
      // Convert CSV rows to RouteSteps
      addLog('info', '3단계: CSV 행을 RouteStep으로 변환');
      const routeSteps: RouteStep[] = [];
      let validCount = 0;
      let invalidCount = 0;
      
      csvData.forEach((row, index) => {
        const step = csvRowToRouteStep(row, index);
        if (step !== null) {
          routeSteps.push(step);
          validCount++;
        } else {
          invalidCount++;
        }
      });

      addLog('info', '4단계: 변환 결과');
      addLog('info', '✓ 유효한 경로 단계:', validCount);
      addLog('warn', '✗ 무효/건너뛴 행:', invalidCount);
      addLog('info', '성공률:', ((validCount / csvData.length) * 100).toFixed(1) + '%');

      if (routeSteps.length === 0) {
        addLog('error', '!!! 오류: 유효한 경로 단계를 찾을 수 없습니다 !!!');
        addLog('error', '열 이름이 예상 값과 일치하지 않습니다');
        addLog('error', '실제 열:', Object.keys(csvData[0]).join(', '));
        
        const columnNames = Object.keys(csvData[0]).join(', ');
        Alert.alert(
          '열 이름 확인 필요',
          `CSV 파일에서 다음 열을 찾았습니다:\n\n${columnNames}\n\n위도, 경도 열이 있는지 확인해주세요.`,
          [{ text: '확인' }]
        );
        
        throw new Error('유효한 경로 데이터를 찾을 수 없습니다.\n\nCSV 파일의 열 이름을 확인해주세요.');
      }

      addLog('info', '5단계: 샘플 파싱 데이터');
      addLog('info', '첫 번째 경로 단계:', JSON.stringify(routeSteps[0], null, 2));
      if (routeSteps.length > 1) {
        addLog('info', '마지막 경로 단계:', JSON.stringify(routeSteps[routeSteps.length - 1], null, 2));
      }

      // Calculate statistics
      addLog('info', '6단계: 통계 계산');
      const redistributionAmount = routeSteps.reduce(
        (sum, step) => sum + Math.abs(step.ActionAmount),
        0
      );

      addLog('info', '총 재배치량:', redistributionAmount, '대');

      // Estimate distance (simplified calculation using Haversine formula)
      addLog('info', '7단계: 총 거리 계산');
      let totalDistance = 0;
      for (let i = 0; i < routeSteps.length - 1; i++) {
        const lat1 = routeSteps[i].Latitude;
        const lon1 = routeSteps[i].Longitude;
        const lat2 = routeSteps[i + 1].Latitude;
        const lon2 = routeSteps[i + 1].Longitude;
        
        // Haversine formula for distance calculation
        const R = 6371; // Earth's radius in km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = 
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
          Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = R * c;
        
        totalDistance += distance;
      }

      addLog('info', '총 거리 계산 완료:', totalDistance.toFixed(2), 'km');

      // Estimate time (assuming average speed of 20 km/h)
      const estimatedTime = Math.round((totalDistance / 20) * 60);
      addLog('info', '예상 시간:', estimatedTime, '분 (', (estimatedTime / 60).toFixed(1), '시간)');

      const pathResult: PathResult = {
        redistributionAmount,
        route: routeSteps.map(step => step.StationID),
        totalDistance: Math.round(totalDistance * 10) / 10,
        estimatedTime,
        routeSteps,
      };
      
      addLog('info', '8단계: 경로 결과 생성');
      addLog('info', '결과 요약:', {
        redistributionAmount: pathResult.redistributionAmount,
        totalDistance: pathResult.totalDistance,
        estimatedTime: pathResult.estimatedTime,
        stepsCount: pathResult.routeSteps.length,
        firstStation: pathResult.route[0],
        lastStation: pathResult.route[pathResult.route.length - 1],
      });
      
      addLog('info', '9단계: UI 상태 업데이트');
      setResult(pathResult);
      addLog('info', '✓ 결과 상태 업데이트 완료');
      
      addLog('info', '10단계: 지도 모달 열기');
      setShowMap(true);
      addLog('info', '✓ 지도 모달 열림');
      
      addLog('info', '11단계: 성공 알림 표시');
      Alert.alert(
        '✅ 경로 계산 완료!',
        `${routeSteps.length}개의 정류장을 포함한 최적 경로를 찾았습니다.\n\n` +
        `📍 재배치량: ${redistributionAmount}대\n` +
        `📏 총 거리: ${pathResult.totalDistance}km\n` +
        `⏱️ 예상 시간: ${estimatedTime}분`,
        [{ text: '확인' }]
      );
      
      addLog('info', '========================================');
      addLog('info', '경로 계산 성공적으로 완료');
      addLog('info', '========================================');
      
    } catch (error) {
      addLog('error', '========================================');
      addLog('error', '경로 계산 오류 발생');
      addLog('error', '========================================');
      addLog('error', '오류 타입:', error instanceof Error ? error.constructor.name : typeof error);
      addLog('error', '오류 메시지:', error instanceof Error ? error.message : String(error));
      
      let errorMessage = 'CSV 데이터를 불러오는 중 오류가 발생했습니다.';
      
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      Alert.alert(
        '❌ 오류 발생',
        errorMessage,
        [
          { text: '확인' },
          { 
            text: '설정 방법 보기', 
            onPress: showHelpDialog
          },
          { 
            text: '연결 테스트', 
            onPress: testCSVConnection
          },
        ]
      );
      
      addLog('error', '========================================');
      addLog('error', '오류 처리 완료');
      addLog('error', '========================================');
    } finally {
      setIsCalculating(false);
      addLog('info', '로딩 상태 false로 설정');
    }
  };

  const handleLogout = () => {
    Alert.alert(
      '로그아웃',
      '정말 로그아웃 하시겠습니까?',
      [
        { text: '취소', style: 'cancel' },
        {
          text: '로그아웃',
          style: 'destructive',
          onPress: () => {
            logout();
            router.replace('/login');
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>안녕하세요,</Text>
          <Text style={styles.userName}>{user?.name || '사용자'}님</Text>
        </View>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
          <IconSymbol name="rectangle.portrait.and.arrow.right" size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <IconSymbol name="bicycle" size={32} color={colors.primary} />
            <Text style={styles.cardTitle}>자전거 재배치</Text>
          </View>
          <Text style={styles.cardDescription}>
            최적의 경로를 찾아 효율적인 자전거 재배치를 수행하세요
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.findPathButton, isCalculating && styles.buttonDisabled]}
          onPress={() => {
            addLog('info', '🔴 경로 찾기 버튼 클릭됨');
            calculateOptimalPath();
          }}
          disabled={isCalculating}
        >
          {isCalculating ? (
            <>
              <ActivityIndicator color="#ffffff" />
              <Text style={[styles.findPathButtonText, { marginLeft: 8 }]}>
                경로 계산 중...
              </Text>
            </>
          ) : (
            <>
              <IconSymbol name="map" size={24} color="#ffffff" />
              <Text style={styles.findPathButtonText}>경로 찾기</Text>
            </>
          )}
        </TouchableOpacity>

        {/* Help and Debug buttons */}
        <View style={styles.debugButtonsContainer}>
          <TouchableOpacity
            style={[styles.helpButton, isCalculating && styles.buttonDisabled]}
            onPress={showHelpDialog}
            disabled={isCalculating}
          >
            <IconSymbol name="questionmark.circle.fill" size={20} color="#ffffff" />
            <Text style={styles.helpButtonText}>설정 방법</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.debugButton, isCalculating && styles.buttonDisabled]}
            onPress={testCSVConnection}
            disabled={isCalculating}
          >
            <IconSymbol name="info.circle" size={20} color={colors.primary} />
            <Text style={styles.debugButtonText}>연결 테스트</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.debugButton, isCalculating && styles.buttonDisabled]}
            onPress={openURLInBrowser}
            disabled={isCalculating}
          >
            <IconSymbol name="arrow.up.right.square" size={20} color={colors.primary} />
            <Text style={styles.debugButtonText}>브라우저</Text>
          </TouchableOpacity>
        </View>

        {/* Console Display */}
        {logs.length > 0 && (
          <ConsoleDisplay logs={logs} onClear={clearLogs} />
        )}

        {result && (
          <View style={styles.resultContainer}>
            <Text style={styles.resultTitle}>최적 경로 결과</Text>
            
            <View style={styles.resultCard}>
              <View style={styles.resultRow}>
                <Text style={styles.resultLabel}>재배치량</Text>
                <Text style={styles.resultValue}>{result.redistributionAmount}대</Text>
              </View>
              
              <View style={styles.resultRow}>
                <Text style={styles.resultLabel}>총 거리</Text>
                <Text style={styles.resultValue}>{result.totalDistance}km</Text>
              </View>
              
              <View style={styles.resultRow}>
                <Text style={styles.resultLabel}>예상 시간</Text>
                <Text style={styles.resultValue}>{result.estimatedTime}분</Text>
              </View>

              <View style={[styles.resultRow, { borderBottomWidth: 0 }]}>
                <Text style={styles.resultLabel}>정류장 수</Text>
                <Text style={styles.resultValue}>{result.routeSteps.length}개</Text>
              </View>
            </View>

            <TouchableOpacity
              style={styles.viewMapButton}
              onPress={() => {
                addLog('info', '지도 보기 버튼 클릭됨');
                setShowMap(true);
              }}
            >
              <IconSymbol name="map.fill" size={20} color="#ffffff" />
              <Text style={styles.viewMapButtonText}>지도에서 경로 보기</Text>
            </TouchableOpacity>

            <View style={styles.routeContainer}>
              <Text style={styles.routeTitle}>경로 ({result.route.length}개 정류장)</Text>
              {result.route.slice(0, 5).map((station, index) => (
                <View key={index} style={styles.routeItem}>
                  <View style={styles.routeNumber}>
                    <Text style={styles.routeNumberText}>{index + 1}</Text>
                  </View>
                  <Text style={styles.routeStation}>{station}</Text>
                  {index < Math.min(result.route.length - 1, 4) && (
                    <IconSymbol name="arrow.down" size={16} color={colors.textSecondary} />
                  )}
                </View>
              ))}
              {result.route.length > 5 && (
                <Text style={styles.moreStations}>
                  외 {result.route.length - 5}개 정류장...
                </Text>
              )}
            </View>

            <TouchableOpacity
              style={styles.resetButton}
              onPress={() => {
                addLog('info', '결과 및 지도 초기화');
                setResult(null);
                setShowMap(false);
              }}
            >
              <Text style={styles.resetButtonText}>새로운 경로 찾기</Text>
            </TouchableOpacity>
          </View>
        )}

        {!result && !isCalculating && (
          <View style={styles.infoContainer}>
            <IconSymbol name="info.circle" size={48} color={colors.textSecondary} />
            <Text style={styles.infoText}>
              경로 찾기 버튼을 눌러 최적의 자전거 재배치 경로를 확인하세요
            </Text>
            <Text style={styles.infoSubtext}>
              Google Cloud Storage에서 실시간 데이터를 불러옵니다
            </Text>
            <Text style={styles.infoHint}>
              문제가 발생하면 "설정 방법" 버튼을 눌러 도움말을 확인하세요
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Map Modal */}
      <Modal
        visible={showMap && result !== null}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => {
          addLog('info', '지도 모달 닫기 요청됨');
          setShowMap(false);
        }}
      >
        {result && result.routeSteps && result.routeSteps.length > 0 ? (
          <RouteMapView
            steps={result.routeSteps}
            onClose={() => {
              addLog('info', 'RouteMapView에서 지도 닫기');
              setShowMap(false);
            }}
          />
        ) : (
          <View style={styles.modalErrorContainer}>
            <Text style={styles.modalErrorText}>경로 데이터를 불러올 수 없습니다</Text>
            <TouchableOpacity
              style={styles.modalCloseButton}
              onPress={() => setShowMap(false)}
            >
              <Text style={styles.modalCloseButtonText}>닫기</Text>
            </TouchableOpacity>
          </View>
        )}
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: colors.card,
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  greeting: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  logoutButton: {
    padding: 8,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    padding: 24,
    paddingBottom: 100,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginLeft: 12,
  },
  cardDescription: {
    fontSize: 16,
    color: colors.textSecondary,
    lineHeight: 24,
  },
  findPathButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    boxShadow: '0px 4px 12px rgba(3, 169, 244, 0.3)',
    elevation: 4,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  findPathButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginLeft: 8,
  },
  debugButtonsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 24,
  },
  helpButton: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: '#FF9800',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  helpButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
    marginLeft: 6,
  },
  debugButton: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.primary,
  },
  debugButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.primary,
    marginLeft: 6,
  },
  resultContainer: {
    marginTop: 8,
  },
  resultTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  resultCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  resultRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.background,
  },
  resultLabel: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  resultValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.primary,
  },
  viewMapButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(76, 175, 80, 0.3)',
    elevation: 4,
  },
  viewMapButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
    marginLeft: 8,
  },
  routeContainer: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  routeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  routeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  routeNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  routeNumberText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  routeStation: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  moreStations: {
    fontSize: 14,
    color: colors.textSecondary,
    fontStyle: 'italic',
    marginTop: 8,
    textAlign: 'center',
  },
  resetButton: {
    backgroundColor: colors.secondary,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  resetButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
  },
  infoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  infoText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 16,
    lineHeight: 24,
  },
  infoSubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 8,
    fontStyle: 'italic',
  },
  infoHint: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 12,
    fontStyle: 'italic',
  },
  modalErrorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
    padding: 24,
  },
  modalErrorText: {
    fontSize: 18,
    color: colors.text,
    textAlign: 'center',
    marginBottom: 24,
  },
  modalCloseButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  modalCloseButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
