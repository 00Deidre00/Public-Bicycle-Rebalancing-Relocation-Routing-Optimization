
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Modal,
} from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { IconSymbol } from '@/components/IconSymbol';
import RouteMapView from '@/components/RouteMapView';
import { RouteStep } from '@/types/RouteData';

interface PathResult {
  redistributionAmount: number;
  route: string[];
  totalDistance: number;
  estimatedTime: number;
  routeSteps: RouteStep[];
}

export default function HomeScreen() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [isCalculating, setIsCalculating] = useState(false);
  const [result, setResult] = useState<PathResult | null>(null);
  const [showMap, setShowMap] = useState(false);

  // Simulated bicycle redistribution algorithm with real coordinates
  const calculateOptimalPath = async () => {
    setIsCalculating(true);
    
    // Simulate algorithm processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Simulated result with real Seoul bike station coordinates
    const mockRouteSteps: RouteStep[] = [
      {
        Step: 1,
        ClusterID: 'C1',
        StationID: '스테이션 A',
        Latitude: 37.5665,
        Longitude: 126.9780,
        ActionAmount: 5,
        TruckLoad_Before: 0,
        TruckLoad_After: 5,
      },
      {
        Step: 2,
        ClusterID: 'C1',
        StationID: '스테이션 B',
        Latitude: 37.5700,
        Longitude: 126.9850,
        ActionAmount: -3,
        TruckLoad_Before: 5,
        TruckLoad_After: 2,
      },
      {
        Step: 3,
        ClusterID: 'C2',
        StationID: '스테이션 C',
        Latitude: 37.5750,
        Longitude: 126.9900,
        ActionAmount: 8,
        TruckLoad_Before: 2,
        TruckLoad_After: 10,
      },
      {
        Step: 4,
        ClusterID: 'C2',
        StationID: '스테이션 D',
        Latitude: 37.5800,
        Longitude: 126.9950,
        ActionAmount: -5,
        TruckLoad_Before: 10,
        TruckLoad_After: 5,
      },
      {
        Step: 5,
        ClusterID: 'C3',
        StationID: '스테이션 E',
        Latitude: 37.5650,
        Longitude: 127.0000,
        ActionAmount: -5,
        TruckLoad_Before: 5,
        TruckLoad_After: 0,
      },
    ];

    const mockResult: PathResult = {
      redistributionAmount: 15,
      route: mockRouteSteps.map(step => step.StationID),
      totalDistance: 8.5,
      estimatedTime: 45,
      routeSteps: mockRouteSteps,
    };
    
    setResult(mockResult);
    setIsCalculating(false);
    
    // Automatically show map after calculation
    setShowMap(true);
  };

  const handleLogout = () => {
    Alert.alert(
      '로그아웃',
      '정말 로그아웃 하시겠습니까?',
      [
        { text: '취소', style: 'cancel' },
        {
          text: '로그아웃',
          style: 'destructive',
          onPress: () => {
            logout();
            router.replace('/login');
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>안녕하세요,</Text>
          <Text style={styles.userName}>{user?.name || '사용자'}님</Text>
        </View>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
          <IconSymbol name="rectangle.portrait.and.arrow.right" size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <IconSymbol name="bicycle" size={32} color={colors.primary} />
            <Text style={styles.cardTitle}>자전거 재배치</Text>
          </View>
          <Text style={styles.cardDescription}>
            최적의 경로를 찾아 효율적인 자전거 재배치를 수행하세요
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.findPathButton, isCalculating && styles.buttonDisabled]}
          onPress={calculateOptimalPath}
          disabled={isCalculating}
        >
          {isCalculating ? (
            <ActivityIndicator color="#ffffff" />
          ) : (
            <>
              <IconSymbol name="map" size={24} color="#ffffff" />
              <Text style={styles.findPathButtonText}>경로 찾기</Text>
            </>
          )}
        </TouchableOpacity>

        {result && (
          <View style={styles.resultContainer}>
            <Text style={styles.resultTitle}>최적 경로 결과</Text>
            
            <View style={styles.resultCard}>
              <View style={styles.resultRow}>
                <Text style={styles.resultLabel}>재배치량</Text>
                <Text style={styles.resultValue}>{result.redistributionAmount}대</Text>
              </View>
              
              <View style={styles.resultRow}>
                <Text style={styles.resultLabel}>총 거리</Text>
                <Text style={styles.resultValue}>{result.totalDistance}km</Text>
              </View>
              
              <View style={styles.resultRow}>
                <Text style={styles.resultLabel}>예상 시간</Text>
                <Text style={styles.resultValue}>{result.estimatedTime}분</Text>
              </View>
            </View>

            <TouchableOpacity
              style={styles.viewMapButton}
              onPress={() => setShowMap(true)}
            >
              <IconSymbol name="map.fill" size={20} color="#ffffff" />
              <Text style={styles.viewMapButtonText}>지도에서 경로 보기</Text>
            </TouchableOpacity>

            <View style={styles.routeContainer}>
              <Text style={styles.routeTitle}>경로</Text>
              {result.route.map((station, index) => (
                <View key={index} style={styles.routeItem}>
                  <View style={styles.routeNumber}>
                    <Text style={styles.routeNumberText}>{index + 1}</Text>
                  </View>
                  <Text style={styles.routeStation}>{station}</Text>
                  {index < result.route.length - 1 && (
                    <IconSymbol name="arrow.down" size={16} color={colors.textSecondary} />
                  )}
                </View>
              ))}
            </View>

            <TouchableOpacity
              style={styles.resetButton}
              onPress={() => {
                setResult(null);
                setShowMap(false);
              }}
            >
              <Text style={styles.resetButtonText}>새로운 경로 찾기</Text>
            </TouchableOpacity>
          </View>
        )}

        {!result && !isCalculating && (
          <View style={styles.infoContainer}>
            <IconSymbol name="info.circle" size={48} color={colors.textSecondary} />
            <Text style={styles.infoText}>
              경로 찾기 버튼을 눌러 최적의 자전거 재배치 경로를 확인하세요
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Map Modal */}
      <Modal
        visible={showMap && result !== null}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowMap(false)}
      >
        {result && (
          <RouteMapView
            steps={result.routeSteps}
            onClose={() => setShowMap(false)}
          />
        )}
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: colors.card,
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  greeting: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  logoutButton: {
    padding: 8,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    padding: 24,
    paddingBottom: 100,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginLeft: 12,
  },
  cardDescription: {
    fontSize: 16,
    color: colors.textSecondary,
    lineHeight: 24,
  },
  findPathButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
    boxShadow: '0px 4px 12px rgba(3, 169, 244, 0.3)',
    elevation: 4,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  findPathButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginLeft: 8,
  },
  resultContainer: {
    marginTop: 8,
  },
  resultTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  resultCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  resultRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.background,
  },
  resultLabel: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  resultValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.primary,
  },
  viewMapButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(76, 175, 80, 0.3)',
    elevation: 4,
  },
  viewMapButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
    marginLeft: 8,
  },
  routeContainer: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  routeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  routeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  routeNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  routeNumberText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  routeStation: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  resetButton: {
    backgroundColor: colors.secondary,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  resetButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
  },
  infoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  infoText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 16,
    lineHeight: 24,
  },
});
