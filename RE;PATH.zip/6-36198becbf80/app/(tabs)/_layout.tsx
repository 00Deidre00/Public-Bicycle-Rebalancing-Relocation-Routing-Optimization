
import { Stack } from 'expo-router';
import FloatingTabBar, { TabBarItem } from '@/components/FloatingTabBar';
import React from 'react';
import { Platform } from 'react-native';
import { colors } from '@/styles/commonStyles';

const tabs: TabBarItem[] = [
  {
    route: '/(tabs)/(home)',
    label: '홈',
    icon: 'house.fill',
  },
  {
    route: '/(tabs)/profile',
    label: '프로필',
    icon: 'person.fill',
  },
];

export default function TabLayout() {
  return (
    <>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(home)" />
        <Stack.Screen name="profile" />
      </Stack>
      {Platform.OS !== 'web' && (
        <FloatingTabBar tabs={tabs} />
      )}
    </>
  );
}
