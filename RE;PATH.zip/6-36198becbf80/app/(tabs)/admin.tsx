
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Platform,
} from 'react-native';
import { colors } from '@/styles/commonStyles';
import { IconSymbol } from '@/components/IconSymbol';
import { fetchAndParseCSV, CSVRow } from '@/utils/csvParser';
import { useAuth } from '@/contexts/AuthContext';

interface TruckRouteData {
  Truck: number;
  Station: string;
  Hour: number;
  LB: number;
  UB: number;
  Target: number;
}

interface TruckRoutes {
  truck1: TruckRouteData[];
  truck2: TruckRouteData[];
  truck3: TruckRouteData[];
}

export default function AdminScreen() {
  const { user, registeredUsers, assignTruckToUser, getDrivers } = useAuth();
  const [selectedTab, setSelectedTab] = useState<'routes' | 'users'>('routes');
  const [selectedTruck, setSelectedTruck] = useState<1 | 2 | 3>(1);
  const [isLoading, setIsLoading] = useState(false);
  const [truckRoutes, setTruckRoutes] = useState<TruckRoutes>({
    truck1: [],
    truck2: [],
    truck3: [],
  });
  const [hasData, setHasData] = useState(false);
  const [csvPreview, setCsvPreview] = useState<string>('');

  // Updated CSV URL
  const CSV_URL = 'https://storage.googleapis.com/output_20251025/1shift3trucksroute_with_coords_en.csv';

  useEffect(() => {
    console.log('========================================');
    console.log('AdminScreen mounted');
    console.log('========================================');
    console.log('Current user:', user);
    console.log('User role:', user?.role);
    console.log('User email:', user?.email);
    console.log('User name:', user?.name);
    console.log('========================================');
    loadTruckRoutes();
  }, []);

  const parseTruckData = (csvData: CSVRow[]): TruckRoutes => {
    console.log('Parsing truck data from CSV...');
    console.log('Total CSV rows:', csvData.length);
    
    // Show first few rows to understand structure
    if (csvData.length > 0) {
      console.log('CSV Headers:', Object.keys(csvData[0]));
      console.log('First row sample:', JSON.stringify(csvData[0], null, 2));
      if (csvData.length > 1) {
        console.log('Second row sample:', JSON.stringify(csvData[1], null, 2));
      }
    }
    
    const routes: TruckRoutes = {
      truck1: [],
      truck2: [],
      truck3: [],
    };

    csvData.forEach((row, index) => {
      try {
        const truckNum = parseInt(row['Truck'] || row['truck'] || '0');
        const station = row['Station'] || row['station'] || '';
        const hour = parseInt(row['Hour'] || row['hour'] || '0');
        const lb = parseInt(row['LB'] || row['lb'] || '0');
        const ub = parseInt(row['UB'] || row['ub'] || '0');
        const target = parseInt(row['Target'] || row['target'] || '0');

        if (truckNum < 1 || truckNum > 3) {
          console.warn(`Row ${index}: Invalid truck number ${truckNum}`);
          return;
        }

        if (!station) {
          console.warn(`Row ${index}: Missing station`);
          return;
        }

        const routeData: TruckRouteData = {
          Truck: truckNum,
          Station: station,
          Hour: hour,
          LB: lb,
          UB: ub,
          Target: target,
        };

        if (truckNum === 1) {
          routes.truck1.push(routeData);
        } else if (truckNum === 2) {
          routes.truck2.push(routeData);
        } else if (truckNum === 3) {
          routes.truck3.push(routeData);
        }
      } catch (error) {
        console.error(`Error parsing row ${index}:`, error);
      }
    });

    console.log('Parsed routes:');
    console.log('Truck 1:', routes.truck1.length, 'stops');
    console.log('Truck 2:', routes.truck2.length, 'stops');
    console.log('Truck 3:', routes.truck3.length, 'stops');

    return routes;
  };

  const loadTruckRoutes = async () => {
    console.log('========================================');
    console.log('Loading truck routes from CSV');
    console.log('========================================');
    console.log('CSV URL:', CSV_URL);
    
    setIsLoading(true);
    
    try {
      console.log('Step 1: Fetching CSV data...');
      const csvData = await fetchAndParseCSV(CSV_URL);
      
      console.log('Step 2: CSV data fetched successfully');
      console.log('Total rows:', csvData.length);
      
      if (csvData.length === 0) {
        throw new Error('CSV 파일이 비어있습니다');
      }

      // Create CSV preview for display
      const headers = Object.keys(csvData[0]);
      let preview = '📄 CSV 파일 내용 미리보기\n\n';
      preview += '컬럼: ' + headers.join(', ') + '\n\n';
      preview += '처음 5개 행:\n';
      preview += '─'.repeat(50) + '\n';
      
      csvData.slice(0, 5).forEach((row, idx) => {
        preview += `\n행 ${idx + 1}:\n`;
        headers.forEach(header => {
          preview += `  ${header}: ${row[header]}\n`;
        });
      });
      
      preview += '\n' + '─'.repeat(50) + '\n';
      preview += `\n총 ${csvData.length}개의 데이터 행`;
      
      setCsvPreview(preview);
      console.log('\n' + preview);

      console.log('Step 3: Parsing truck routes...');
      const routes = parseTruckData(csvData);
      
      console.log('Step 4: Routes parsed successfully');
      setTruckRoutes(routes);
      setHasData(true);
      
      const totalStops = routes.truck1.length + routes.truck2.length + routes.truck3.length;
      
      Alert.alert(
        '✅ 데이터 로드 완료',
        `총 ${totalStops}개의 정류장 데이터를 불러왔습니다.\n\n` +
        `트럭 1: ${routes.truck1.length}개 정류장\n` +
        `트럭 2: ${routes.truck2.length}개 정류장\n` +
        `트럭 3: ${routes.truck3.length}개 정류장\n\n` +
        `컬럼: ${headers.join(', ')}`,
        [{ text: '확인' }]
      );
      
      console.log('========================================');
      console.log('Truck routes loaded successfully');
      console.log('========================================');
      
    } catch (error) {
      console.error('========================================');
      console.error('Error loading truck routes');
      console.error('========================================');
      console.error('Error:', error);
      
      Alert.alert(
        '❌ 데이터 로드 실패',
        `CSV 파일을 불러오는 중 오류가 발생했습니다.\n\n${error instanceof Error ? error.message : String(error)}`,
        [
          { text: '확인' },
          { text: '다시 시도', onPress: loadTruckRoutes }
        ]
      );
    } finally {
      setIsLoading(false);
    }
  };

  const showCsvPreview = () => {
    if (csvPreview) {
      Alert.alert(
        'CSV 파일 내용',
        csvPreview,
        [{ text: '확인' }],
        { cancelable: true }
      );
    }
  };

  const getCurrentTruckData = (): TruckRouteData[] => {
    switch (selectedTruck) {
      case 1:
        return truckRoutes.truck1;
      case 2:
        return truckRoutes.truck2;
      case 3:
        return truckRoutes.truck3;
      default:
        return [];
    }
  };

  const getTruckColor = (truckNum: number | null): string => {
    if (truckNum === null) return colors.textSecondary;
    switch (truckNum) {
      case 1:
        return '#4CAF50';
      case 2:
        return '#2196F3';
      case 3:
        return '#FF9800';
      default:
        return colors.primary;
    }
  };

  const handleAssignTruck = (userId: string, userName: string, currentTruck: number | null) => {
    Alert.alert(
      '트럭 할당',
      `${userName}님에게 할당할 트럭을 선택하세요`,
      [
        { text: '취소', style: 'cancel' },
        { 
          text: '트럭 1', 
          onPress: () => updateUserTruck(userId, userName, 1)
        },
        { 
          text: '트럭 2', 
          onPress: () => updateUserTruck(userId, userName, 2)
        },
        { 
          text: '트럭 3', 
          onPress: () => updateUserTruck(userId, userName, 3)
        },
        ...(currentTruck !== null ? [{ 
          text: '할당 해제', 
          style: 'destructive' as const,
          onPress: () => updateUserTruck(userId, userName, null)
        }] : []),
      ]
    );
  };

  const updateUserTruck = (userId: string, userName: string, truck: number | null) => {
    console.log(`Admin updating truck assignment: userId=${userId}, truck=${truck}`);
    
    assignTruckToUser(userId, truck);
    
    Alert.alert(
      '✅ 성공',
      truck !== null 
        ? `${userName}님에게 트럭 ${truck}이 할당되었습니다`
        : `${userName}님의 트럭 할당이 해제되었습니다`
    );
  };

  const renderTruckSelector = () => {
    return (
      <View style={styles.truckSelector}>
        {[1, 2, 3].map((truckNum) => (
          <TouchableOpacity
            key={truckNum}
            style={[
              styles.truckButton,
              selectedTruck === truckNum && styles.truckButtonActive,
              { borderColor: getTruckColor(truckNum) },
              selectedTruck === truckNum && { backgroundColor: getTruckColor(truckNum) },
            ]}
            onPress={() => setSelectedTruck(truckNum as 1 | 2 | 3)}
          >
            <IconSymbol
              ios_icon_name="truck.box.fill"
              android_material_icon_name="local_shipping"
              size={24}
              color={selectedTruck === truckNum ? '#ffffff' : getTruckColor(truckNum)}
            />
            <Text
              style={[
                styles.truckButtonText,
                selectedTruck === truckNum && styles.truckButtonTextActive,
                { color: selectedTruck === truckNum ? '#ffffff' : getTruckColor(truckNum) },
              ]}
            >
              트럭 {truckNum}
            </Text>
            <View style={styles.truckBadge}>
              <Text style={styles.truckBadgeText}>
                {truckNum === 1 ? truckRoutes.truck1.length : 
                 truckNum === 2 ? truckRoutes.truck2.length : 
                 truckRoutes.truck3.length}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  const renderRouteCard = (route: TruckRouteData, index: number) => {
    const isFirst = index === 0;
    const isLast = index === getCurrentTruckData().length - 1;
    
    return (
      <View key={index} style={styles.routeCard}>
        <View style={styles.routeCardHeader}>
          <View style={[styles.routeNumber, { backgroundColor: getTruckColor(selectedTruck) }]}>
            <Text style={styles.routeNumberText}>{index + 1}</Text>
          </View>
          <View style={styles.routeInfo}>
            <Text style={styles.stationText}>정류장 {route.Station}</Text>
            <Text style={styles.hourText}>시간대: {route.Hour}시</Text>
          </View>
          {isFirst && (
            <View style={styles.startBadge}>
              <Text style={styles.startBadgeText}>출발</Text>
            </View>
          )}
          {isLast && (
            <View style={styles.endBadge}>
              <Text style={styles.endBadgeText}>도착</Text>
            </View>
          )}
        </View>
        
        <View style={styles.routeDetails}>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>하한 (LB)</Text>
            <Text style={styles.detailValue}>{route.LB}</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>상한 (UB)</Text>
            <Text style={styles.detailValue}>{route.UB}</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>목표 (Target)</Text>
            <Text style={[styles.detailValue, styles.targetValue]}>{route.Target}</Text>
          </View>
        </View>

        {!isLast && (
          <View style={styles.routeArrow}>
            <IconSymbol ios_icon_name="arrow.down" android_material_icon_name="arrow_downward" size={20} color={colors.textSecondary} />
          </View>
        )}
      </View>
    );
  };

  const renderTruckSummary = () => {
    const currentData = getCurrentTruckData();
    
    if (currentData.length === 0) {
      return null;
    }

    const totalTarget = currentData.reduce((sum, route) => sum + route.Target, 0);
    const avgTarget = Math.round(totalTarget / currentData.length);
    const hours = [...new Set(currentData.map(r => r.Hour))];
    const minHour = Math.min(...hours);
    const maxHour = Math.max(...hours);

    return (
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>트럭 {selectedTruck} 요약</Text>
        
        <View style={styles.summaryGrid}>
          <View style={styles.summaryItem}>
            <IconSymbol ios_icon_name="mappin.circle.fill" android_material_icon_name="location_on" size={24} color={getTruckColor(selectedTruck)} />
            <Text style={styles.summaryValue}>{currentData.length}</Text>
            <Text style={styles.summaryLabel}>정류장</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <IconSymbol ios_icon_name="clock.fill" android_material_icon_name="schedule" size={24} color={getTruckColor(selectedTruck)} />
            <Text style={styles.summaryValue}>{minHour}-{maxHour}시</Text>
            <Text style={styles.summaryLabel}>운행 시간</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <IconSymbol ios_icon_name="bicycle" android_material_icon_name="directions_bike" size={24} color={getTruckColor(selectedTruck)} />
            <Text style={styles.summaryValue}>{totalTarget}</Text>
            <Text style={styles.summaryLabel}>총 목표</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <IconSymbol ios_icon_name="chart.bar.fill" android_material_icon_name="bar_chart" size={24} color={getTruckColor(selectedTruck)} />
            <Text style={styles.summaryValue}>{avgTarget}</Text>
            <Text style={styles.summaryLabel}>평균 목표</Text>
          </View>
        </View>
      </View>
    );
  };

  const renderUserCard = (driver: any) => {
    return (
      <View key={driver.id} style={styles.userCard}>
        <View style={styles.userCardHeader}>
          <View style={styles.userAvatar}>
            <IconSymbol ios_icon_name="person.fill" android_material_icon_name="person" size={24} color="#ffffff" />
          </View>
          <View style={styles.userInfo}>
            <Text style={styles.userNameText}>{driver.name}</Text>
            <Text style={styles.userEmailText}>{driver.email}</Text>
          </View>
        </View>
        
        <View style={styles.userTruckInfo}>
          {driver.assignedTruck !== null ? (
            <View style={[styles.userTruckBadge, { backgroundColor: getTruckColor(driver.assignedTruck) }]}>
              <IconSymbol ios_icon_name="truck.box.fill" android_material_icon_name="local_shipping" size={16} color="#ffffff" />
              <Text style={styles.userTruckBadgeText}>트럭 {driver.assignedTruck}</Text>
            </View>
          ) : (
            <View style={styles.userNoTruckBadge}>
              <IconSymbol ios_icon_name="exclamationmark.triangle" android_material_icon_name="warning" size={16} color={colors.textSecondary} />
              <Text style={styles.userNoTruckBadgeText}>미할당</Text>
            </View>
          )}
          
          <TouchableOpacity
            style={styles.assignButton}
            onPress={() => handleAssignTruck(driver.id, driver.name, driver.assignedTruck)}
          >
            <IconSymbol 
              ios_icon_name={driver.assignedTruck !== null ? "arrow.triangle.2.circlepath" : "plus.circle"} 
              android_material_icon_name={driver.assignedTruck !== null ? "sync" : "add_circle"}
              size={20} 
              color={colors.primary} 
            />
            <Text style={styles.assignButtonText}>
              {driver.assignedTruck !== null ? '변경' : '할당'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const renderUsersSummary = () => {
    const drivers = getDrivers();
    const assignedDrivers = drivers.filter(d => d.assignedTruck !== null).length;
    const unassignedDrivers = drivers.filter(d => d.assignedTruck === null).length;
    const truck1Drivers = drivers.filter(d => d.assignedTruck === 1).length;
    const truck2Drivers = drivers.filter(d => d.assignedTruck === 2).length;
    const truck3Drivers = drivers.filter(d => d.assignedTruck === 3).length;
    
    return (
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>운전자 현황</Text>
        
        <View style={styles.summaryGrid}>
          <View style={styles.summaryItem}>
            <IconSymbol ios_icon_name="person.3.fill" android_material_icon_name="group" size={24} color={colors.primary} />
            <Text style={styles.summaryValue}>{drivers.length}</Text>
            <Text style={styles.summaryLabel}>전체 운전자</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <IconSymbol ios_icon_name="checkmark.circle.fill" android_material_icon_name="check_circle" size={24} color="#4CAF50" />
            <Text style={styles.summaryValue}>{assignedDrivers}</Text>
            <Text style={styles.summaryLabel}>할당 완료</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <IconSymbol ios_icon_name="exclamationmark.circle.fill" android_material_icon_name="error" size={24} color="#FF9800" />
            <Text style={styles.summaryValue}>{unassignedDrivers}</Text>
            <Text style={styles.summaryLabel}>미할당</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <IconSymbol ios_icon_name="truck.box.fill" android_material_icon_name="local_shipping" size={24} color={colors.primary} />
            <Text style={styles.summaryValue}>3</Text>
            <Text style={styles.summaryLabel}>총 트럭</Text>
          </View>
        </View>
        
        <View style={styles.truckDistribution}>
          <Text style={styles.distributionTitle}>트럭별 할당 현황</Text>
          <View style={styles.distributionRow}>
            <View style={styles.distributionItem}>
              <View style={[styles.distributionDot, { backgroundColor: getTruckColor(1) }]} />
              <Text style={styles.distributionText}>트럭 1: {truck1Drivers}명</Text>
            </View>
            <View style={styles.distributionItem}>
              <View style={[styles.distributionDot, { backgroundColor: getTruckColor(2) }]} />
              <Text style={styles.distributionText}>트럭 2: {truck2Drivers}명</Text>
            </View>
            <View style={styles.distributionItem}>
              <View style={[styles.distributionDot, { backgroundColor: getTruckColor(3) }]} />
              <Text style={styles.distributionText}>트럭 3: {truck3Drivers}명</Text>
            </View>
          </View>
        </View>
      </View>
    );
  };

  // Check if user is admin
  if (user?.role !== 'admin') {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>관리자 화면</Text>
        </View>
        <View style={styles.noAccessContainer}>
          <IconSymbol ios_icon_name="lock.fill" android_material_icon_name="lock" size={64} color={colors.textSecondary} />
          <Text style={styles.noAccessText}>관리자 권한이 필요합니다</Text>
          <Text style={styles.noAccessSubtext}>
            이 화면은 관리자만 접근할 수 있습니다.
          </Text>
          <Text style={styles.debugText}>
            현재 사용자: {user?.email || '없음'}
          </Text>
          <Text style={styles.debugText}>
            현재 역할: {user?.role || '없음'}
          </Text>
        </View>
      </View>
    );
  }

  if (isLoading) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>관리자 화면</Text>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>트럭 경로 데이터 로딩 중...</Text>
          <Text style={styles.loadingSubtext}>
            {CSV_URL.split('/').pop()}
          </Text>
        </View>
      </View>
    );
  }

  console.log('========================================');
  console.log('RENDERING ADMIN SCREEN');
  console.log('User:', user?.email, 'Role:', user?.role);
  console.log('Selected Tab:', selectedTab);
  console.log('Has Data:', hasData);
  console.log('========================================');

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>관리자 화면</Text>
          <Text style={styles.subtitle}>
            {user?.name || '관리자'}님 ({user?.email || ''})
          </Text>
        </View>
        <View style={styles.headerButtons}>
          {csvPreview && selectedTab === 'routes' && (
            <TouchableOpacity
              style={styles.previewButton}
              onPress={showCsvPreview}
            >
              <IconSymbol ios_icon_name="doc.text" android_material_icon_name="description" size={24} color={colors.primary} />
            </TouchableOpacity>
          )}
          {selectedTab === 'routes' && (
            <TouchableOpacity
              style={styles.refreshButton}
              onPress={loadTruckRoutes}
            >
              <IconSymbol ios_icon_name="arrow.clockwise" android_material_icon_name="refresh" size={24} color={colors.primary} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* ULTRA MEGA VISIBLE Tab Selector - Cannot be missed! */}
      <View style={styles.megaTabContainer}>
        <View style={styles.megaTabHeader}>
          <Text style={styles.megaTabHeaderText}>⚙️ 관리 메뉴 선택</Text>
          <Text style={styles.megaTabSubtext}>아래 버튼을 눌러 메뉴를 선택하세요</Text>
        </View>
        
        <View style={styles.megaTabButtons}>
          <TouchableOpacity
            style={[
              styles.megaTabButton,
              selectedTab === 'routes' && styles.megaTabButtonActive,
            ]}
            onPress={() => {
              console.log('🗺️🗺️🗺️ ROUTES TAB PRESSED 🗺️🗺️🗺️');
              setSelectedTab('routes');
            }}
            activeOpacity={0.7}
          >
            <View style={styles.megaTabIconContainer}>
              <IconSymbol 
                ios_icon_name="map.fill" 
                android_material_icon_name="map"
                size={48} 
                color={selectedTab === 'routes' ? '#ffffff' : '#FF6B35'} 
              />
            </View>
            <Text style={[
              styles.megaTabButtonText,
              selectedTab === 'routes' && styles.megaTabButtonTextActive,
            ]}>
              🗺️ 경로 관리
            </Text>
            <Text style={[
              styles.megaTabButtonSubtext,
              selectedTab === 'routes' && styles.megaTabButtonSubtextActive,
            ]}>
              트럭 경로 확인
            </Text>
            {selectedTab === 'routes' && (
              <View style={styles.megaActiveIndicator}>
                <Text style={styles.megaActiveIndicatorText}>✓ 선택됨</Text>
              </View>
            )}
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.megaTabButton,
              selectedTab === 'users' && styles.megaTabButtonActive,
            ]}
            onPress={() => {
              console.log('👥👥👥 USERS TAB PRESSED 👥👥👥');
              setSelectedTab('users');
            }}
            activeOpacity={0.7}
          >
            <View style={styles.megaTabIconContainer}>
              <IconSymbol 
                ios_icon_name="person.3.fill" 
                android_material_icon_name="group"
                size={48} 
                color={selectedTab === 'users' ? '#ffffff' : '#4ECDC4'} 
              />
            </View>
            <Text style={[
              styles.megaTabButtonText,
              selectedTab === 'users' && styles.megaTabButtonTextActive,
            ]}>
              👥 운전자 관리
            </Text>
            <Text style={[
              styles.megaTabButtonSubtext,
              selectedTab === 'users' && styles.megaTabButtonSubtextActive,
            ]}>
              트럭 할당 관리
            </Text>
            {selectedTab === 'users' && (
              <View style={styles.megaActiveIndicator}>
                <Text style={styles.megaActiveIndicatorText}>✓ 선택됨</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
        
        <View style={styles.megaTabIndicator}>
          <Text style={styles.megaTabIndicatorText}>
            현재 선택: {selectedTab === 'routes' ? '🗺️ 경로 관리' : '👥 운전자 관리'}
          </Text>
        </View>
      </View>

      {selectedTab === 'routes' ? (
        !hasData ? (
          <View style={styles.emptyContainer}>
            <IconSymbol ios_icon_name="exclamationmark.triangle" android_material_icon_name="warning" size={64} color={colors.textSecondary} />
            <Text style={styles.emptyText}>데이터를 불러오지 못했습니다</Text>
            <Text style={styles.emptySubtext}>
              파일: {CSV_URL.split('/').pop()}
            </Text>
            <TouchableOpacity
              style={styles.retryButton}
              onPress={loadTruckRoutes}
            >
              <IconSymbol ios_icon_name="arrow.clockwise" android_material_icon_name="refresh" size={20} color="#ffffff" />
              <Text style={styles.retryButtonText}>다시 시도</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            {renderTruckSelector()}
            
            <ScrollView
              style={styles.content}
              contentContainerStyle={styles.contentContainer}
              showsVerticalScrollIndicator={false}
            >
              {renderTruckSummary()}
              
              <View style={styles.routesSection}>
                <Text style={styles.sectionTitle}>
                  📍 트럭 {selectedTruck} 경로 ({getCurrentTruckData().length}개 정류장)
                </Text>
                
                {getCurrentTruckData().length === 0 ? (
                  <View style={styles.noDataCard}>
                    <IconSymbol ios_icon_name="info.circle" android_material_icon_name="info" size={48} color={colors.textSecondary} />
                    <Text style={styles.noDataText}>
                      트럭 {selectedTruck}의 경로 데이터가 없습니다
                    </Text>
                  </View>
                ) : (
                  getCurrentTruckData().map((route, index) => renderRouteCard(route, index))
                )}
              </View>
            </ScrollView>
          </>
        )
      ) : (
        <ScrollView
          style={styles.content}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          {renderUsersSummary()}
          
          <View style={styles.usersSection}>
            <Text style={styles.sectionTitle}>
              👥 운전자 목록 ({getDrivers().length}명)
            </Text>
            
            {getDrivers().length === 0 ? (
              <View style={styles.noDataCard}>
                <IconSymbol ios_icon_name="person.fill.questionmark" android_material_icon_name="person" size={48} color={colors.textSecondary} />
                <Text style={styles.noDataText}>
                  등록된 운전자가 없습니다
                </Text>
                <Text style={styles.noDataSubtext}>
                  회원가입 시 &quot;운전자&quot; 역할을 선택하여 가입하세요
                </Text>
              </View>
            ) : (
              getDrivers().map(driver => renderUserCard(driver))
            )}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'android' ? 48 : 60,
    paddingBottom: 20,
    backgroundColor: colors.card,
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  previewButton: {
    padding: 8,
    marginRight: 8,
  },
  refreshButton: {
    padding: 8,
  },
  megaTabContainer: {
    backgroundColor: '#ffffff',
    paddingVertical: 24,
    paddingHorizontal: 20,
    borderBottomWidth: 4,
    borderBottomColor: '#e0e0e0',
    boxShadow: '0px 8px 16px rgba(0, 0, 0, 0.25)',
    elevation: 10,
  },
  megaTabHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  megaTabHeaderText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 8,
  },
  megaTabSubtext: {
    fontSize: 16,
    color: '#666666',
  },
  megaTabButtons: {
    flexDirection: 'row',
    gap: 20,
    marginBottom: 20,
  },
  megaTabButton: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    borderRadius: 24,
    paddingVertical: 32,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 4,
    borderColor: '#e0e0e0',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
    elevation: 6,
    minHeight: 200,
  },
  megaTabButtonActive: {
    backgroundColor: '#FF6B35',
    borderColor: '#ffffff',
    boxShadow: '0px 12px 32px rgba(255, 107, 53, 0.5)',
    elevation: 16,
    transform: [{ scale: 1.05 }],
  },
  megaTabIconContainer: {
    marginBottom: 16,
    padding: 16,
    borderRadius: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  megaTabButtonText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333333',
    textAlign: 'center',
    marginBottom: 8,
  },
  megaTabButtonTextActive: {
    color: '#ffffff',
  },
  megaTabButtonSubtext: {
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
  },
  megaTabButtonSubtextActive: {
    color: 'rgba(255, 255, 255, 0.9)',
  },
  megaActiveIndicator: {
    marginTop: 16,
    paddingVertical: 8,
    paddingHorizontal: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 20,
  },
  megaActiveIndicatorText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  megaTabIndicator: {
    backgroundColor: '#4ECDC4',
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  megaTabIndicatorText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  noAccessContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  noAccessText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 16,
    textAlign: 'center',
  },
  noAccessSubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 8,
    textAlign: 'center',
  },
  debugText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textSecondary,
  },
  loadingSubtext: {
    marginTop: 8,
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: {
    fontSize: 18,
    color: colors.textSecondary,
    marginTop: 16,
    textAlign: 'center',
  },
  emptySubtext: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 8,
    marginBottom: 24,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
  },
  retryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginLeft: 8,
  },
  truckSelector: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  truckButton: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 8,
    marginHorizontal: 4,
    borderRadius: 12,
    borderWidth: 2,
    backgroundColor: colors.background,
  },
  truckButtonActive: {
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
    elevation: 4,
  },
  truckButtonText: {
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
  },
  truckButtonTextActive: {
    fontWeight: 'bold',
  },
  truckBadge: {
    marginTop: 8,
    backgroundColor: colors.background,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  truckBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.text,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 100,
  },
  summaryCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 3,
  },
  summaryTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  summaryItem: {
    width: '48%',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.background,
    borderRadius: 12,
    marginBottom: 12,
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 8,
  },
  summaryLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
  },
  truckDistribution: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: colors.background,
  },
  distributionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 12,
  },
  distributionRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  distributionItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  distributionDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  distributionText: {
    fontSize: 14,
    color: colors.text,
  },
  routesSection: {
    marginBottom: 20,
  },
  usersSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  routeCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  routeCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  routeNumber: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  routeNumberText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  routeInfo: {
    flex: 1,
  },
  stationText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
  },
  hourText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  startBadge: {
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  startBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  endBadge: {
    backgroundColor: '#F44336',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  endBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  routeDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: colors.background,
  },
  detailItem: {
    flex: 1,
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 11,
    color: colors.textSecondary,
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
  },
  targetValue: {
    color: colors.primary,
  },
  routeArrow: {
    alignItems: 'center',
    marginTop: 8,
  },
  noDataCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 40,
    alignItems: 'center',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  noDataText: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 16,
    textAlign: 'center',
  },
  noDataSubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 8,
    textAlign: 'center',
  },
  userCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  userCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  userAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  userInfo: {
    flex: 1,
  },
  userNameText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
  },
  userEmailText: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 2,
  },
  userTruckInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  userTruckBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  userTruckBadgeText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
    marginLeft: 6,
  },
  userNoTruckBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: colors.background,
  },
  userNoTruckBadgeText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textSecondary,
    marginLeft: 6,
  },
  assignButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: colors.background,
    borderWidth: 2,
    borderColor: colors.primary,
  },
  assignButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
    marginLeft: 6,
  },
});
