
import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { colors } from '@/styles/commonStyles';
import { IconSymbol } from './IconSymbol';

interface LogEntry {
  timestamp: string;
  type: 'log' | 'warn' | 'error' | 'info';
  message: string;
}

interface ConsoleDisplayProps {
  logs: LogEntry[];
  onClear: () => void;
}

export default function ConsoleDisplay({ logs, onClear }: ConsoleDisplayProps) {
  const scrollViewRef = useRef<ScrollView>(null);

  useEffect(() => {
    // Auto-scroll to bottom when new logs are added
    if (scrollViewRef.current && logs.length > 0) {
      scrollViewRef.current.scrollToEnd({ animated: true });
    }
  }, [logs.length]);

  const getLogColor = (type: string) => {
    switch (type) {
      case 'error':
        return '#F44336';
      case 'warn':
        return '#FF9800';
      case 'info':
        return '#2196F3';
      default:
        return colors.text;
    }
  };

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'error':
        return 'xmark.circle.fill';
      case 'warn':
        return 'exclamationmark.triangle.fill';
      case 'info':
        return 'info.circle.fill';
      default:
        return 'text.bubble.fill';
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>실시간 로그 ({logs.length})</Text>
        <TouchableOpacity onPress={onClear} style={styles.clearButton}>
          <IconSymbol name="trash.fill" size={20} color="#ffffff" />
          <Text style={styles.clearButtonText}>지우기</Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView
        ref={scrollViewRef}
        style={styles.logContainer}
        contentContainerStyle={styles.logContent}
        showsVerticalScrollIndicator={true}
      >
        {logs.length === 0 ? (
          <View style={styles.emptyContainer}>
            <IconSymbol name="text.bubble" size={48} color={colors.textSecondary} />
            <Text style={styles.emptyText}>로그가 없습니다</Text>
          </View>
        ) : (
          logs.map((log, index) => (
            <View key={index} style={styles.logEntry}>
              <View style={styles.logHeader}>
                <IconSymbol
                  name={getLogIcon(log.type)}
                  size={16}
                  color={getLogColor(log.type)}
                />
                <Text style={[styles.logType, { color: getLogColor(log.type) }]}>
                  {log.type.toUpperCase()}
                </Text>
                <Text style={styles.logTimestamp}>{log.timestamp}</Text>
              </View>
              <Text style={[styles.logMessage, { color: getLogColor(log.type) }]}>
                {log.message}
              </Text>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 2,
    borderColor: colors.primary,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.primary,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  clearButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  clearButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
    marginLeft: 6,
  },
  logContainer: {
    maxHeight: 400,
    backgroundColor: '#1E1E1E',
  },
  logContent: {
    padding: 12,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 12,
  },
  logEntry: {
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  logHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  logType: {
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 6,
  },
  logTimestamp: {
    fontSize: 10,
    color: '#888888',
    marginLeft: 8,
  },
  logMessage: {
    fontSize: 13,
    lineHeight: 20,
    fontFamily: 'monospace',
  },
});
