
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Platform,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import Svg, { Circle, Line, Polyline, Text as SvgText, G } from 'react-native-svg';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { RouteStep } from '@/types/RouteData';
import * as Location from 'expo-location';
import { 
  fetchRoutesForPath, 
  RoutePoint, 
  RouteSegment,
} from '@/utils/routingService';
import { testOpenRouteServiceAPI } from '@/utils/orsApiTest';

interface RouteMapViewProps {
  steps: RouteStep[];
  onClose: () => void;
}

interface WarningBanner {
  id: string;
  type: 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

const ORS_API_KEY = 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6ImM4YmRjZGQzMzI2NGE1MWY5YTkwMzhkN2VmOThmN2YxODMyM2U5OTFjMTE2NGJmYWNkMmZlOWMzIiwiaCI6Im11cm11cjY0In0=';

export default function RouteMapView({ steps, onClose }: RouteMapViewProps) {
  const [hasLocationPermission, setHasLocationPermission] = useState(false);
  const [isLoadingPermission, setIsLoadingPermission] = useState(true);
  const [isLoadingRoutes, setIsLoadingRoutes] = useState(false);
  const [routeSegments, setRouteSegments] = useState<RouteSegment[]>([]);
  const [loadingProgress, setLoadingProgress] = useState({ current: 0, total: 0 });
  const [totalDistance, setTotalDistance] = useState(0);
  const [totalDuration, setTotalDuration] = useState(0);
  const [selectedStep, setSelectedStep] = useState<number | null>(null);
  const [realRoutesCount, setRealRoutesCount] = useState(0);
  const [warningBanners, setWarningBanners] = useState<WarningBanner[]>([]);
  const [fadeAnim] = useState(new Animated.Value(0));

  const screenWidth = Dimensions.get('window').width;
  const mapWidth = screenWidth - 48;
  const mapHeight = 400;

  useEffect(() => {
    requestLocationPermission();
  }, []);

  useEffect(() => {
    if (steps.length > 0 && hasLocationPermission) {
      loadActualRoutes();
    }
  }, [steps.length, hasLocationPermission]);

  useEffect(() => {
    if (warningBanners.length > 0) {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else {
      fadeAnim.setValue(0);
    }
  }, [warningBanners.length]);

  const addWarningBanner = (type: 'error' | 'warning' | 'info', title: string, message: string) => {
    const id = Date.now().toString();
    setWarningBanners(prev => [...prev, { id, type, title, message }]);
  };

  const removeWarningBanner = (id: string) => {
    setWarningBanners(prev => prev.filter(banner => banner.id !== id));
  };

  const requestLocationPermission = async () => {
    try {
      console.log('Requesting location permission...');
      const { status } = await Location.requestForegroundPermissionsAsync();
      
      if (status === 'granted') {
        console.log('✓ Location permission granted');
        setHasLocationPermission(true);
      } else {
        console.log('✗ Location permission denied');
        setHasLocationPermission(false);
      }
    } catch (error) {
      console.error('Error requesting location permission:', error);
      setHasLocationPermission(false);
    } finally {
      setIsLoadingPermission(false);
    }
  };

  const loadActualRoutes = async () => {
    if (steps.length < 2) {
      console.log('Not enough steps to load routes');
      return;
    }

    setIsLoadingRoutes(true);
    setLoadingProgress({ current: 0, total: steps.length - 1 });
    setWarningBanners([]);

    try {
      console.log('🚴 Loading actual routes using OpenRouteService for', steps.length, 'waypoints...');
      
      const waypoints: RoutePoint[] = steps.map(step => ({
        latitude: step.Latitude,
        longitude: step.Longitude,
      }));

      console.log('🔄 Starting route fetching process...');
      
      const segments = await fetchRoutesForPath(
        waypoints,
        (current, total) => {
          console.log(`📊 Progress: ${current}/${total}`);
          setLoadingProgress({ current, total });
        }
      );

      console.log('✅ Received', segments.length, 'segments');
      
      if (segments.length === 0) {
        throw new Error('경로 세그먼트를 가져오지 못했습니다');
      }

      setRouteSegments(segments);
      
      const distance = segments.reduce((sum, seg) => sum + seg.distance, 0);
      const duration = segments.reduce((sum, seg) => sum + seg.duration, 0);
      const realRoutes = segments.filter(seg => seg.isRealRoute).length;
      
      setTotalDistance(distance);
      setTotalDuration(duration);
      setRealRoutesCount(realRoutes);
      
      console.log('✅ Routes loaded successfully');
      console.log(`📏 Total distance: ${(distance / 1000).toFixed(2)} km`);
      console.log(`⏱️ Total duration: ${(duration / 60).toFixed(0)} minutes`);
      console.log(`✅ Real ORS routes: ${realRoutes}/${segments.length}`);
      console.log(`⚠️ Straight line fallbacks: ${segments.length - realRoutes}/${segments.length}`);
      
      if (realRoutes === 0) {
        console.error('❌❌❌ ALL ROUTES ARE STRAIGHT LINES! ORS API IS NOT WORKING! ❌❌❌');
        addWarningBanner(
          'error',
          '⚠️ 경로 API 오류',
          `OpenRouteService API가 작동하지 않습니다.\n\n모든 경로가 직선으로 표시됩니다.\n\n가능한 원인:\n• API 키가 만료되었거나 잘못됨\n• API 키에 권한이 없음\n• API 요청 한도 초과\n• 네트워크 연결 문제\n• 좌표가 지원 지역 밖\n• API가 인코딩된 폴리라인을 반환하지만 디코딩 실패`
        );
      } else if (realRoutes < segments.length) {
        console.warn(`⚠️ Some routes are straight lines: ${segments.length - realRoutes}/${segments.length}`);
        addWarningBanner(
          'warning',
          '⚠️ 일부 경로 오류',
          `${segments.length - realRoutes}개의 경로가 직선으로 표시됩니다.\n\nOpenRouteService API가 일부 경로에 대해 실패했습니다.`
        );
      } else {
        console.log('✅ All routes successfully loaded from ORS');
        // Success message removed - no banner shown
      }
    } catch (error) {
      console.error('❌ Error loading routes:', error);
      
      addWarningBanner(
        'error',
        '경로 로딩 오류',
        `실제 경로를 불러오는 중 오류가 발생했습니다.\n\n${error instanceof Error ? error.message : '알 수 없는 오류'}\n\n직선 경로로 표시됩니다.`
      );
    } finally {
      setIsLoadingRoutes(false);
      console.log('🏁 Route loading process finished');
    }
  };

  const latLngToSVG = (lat: number, lng: number, bounds: { minLat: number; maxLat: number; minLng: number; maxLng: number }) => {
    const padding = 40;
    const usableWidth = mapWidth - (padding * 2);
    const usableHeight = mapHeight - (padding * 2);

    const x = padding + ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * usableWidth;
    const y = padding + ((bounds.maxLat - lat) / (bounds.maxLat - bounds.minLat)) * usableHeight;

    return { x, y };
  };

  const calculateBounds = () => {
    if (steps.length === 0) {
      return { minLat: 0, maxLat: 0, minLng: 0, maxLng: 0 };
    }

    let minLat = steps[0].Latitude;
    let maxLat = steps[0].Latitude;
    let minLng = steps[0].Longitude;
    let maxLng = steps[0].Longitude;

    steps.forEach(step => {
      minLat = Math.min(minLat, step.Latitude);
      maxLat = Math.max(maxLat, step.Latitude);
      minLng = Math.min(minLng, step.Longitude);
      maxLng = Math.max(maxLng, step.Longitude);
    });

    const latPadding = (maxLat - minLat) * 0.1;
    const lngPadding = (maxLng - minLng) * 0.1;

    return {
      minLat: minLat - latPadding,
      maxLat: maxLat + latPadding,
      minLng: minLng - lngPadding,
      maxLng: maxLng + lngPadding,
    };
  };

  const bounds = calculateBounds();

  const getMarkerColor = (actionAmount: number): string => {
    if (actionAmount > 0) {
      return '#4CAF50';
    } else if (actionAmount < 0) {
      return '#F44336';
    } else {
      return '#2196F3';
    }
  };

  const getActionText = (actionAmount: number): string => {
    if (actionAmount > 0) {
      return `+${actionAmount} 픽업`;
    } else if (actionAmount < 0) {
      return `${actionAmount} 배치`;
    } else {
      return '경유';
    }
  };

  const getBannerColor = (type: 'error' | 'warning' | 'info') => {
    switch (type) {
      case 'error':
        return { bg: '#FFEBEE', border: '#F44336', text: '#C62828' };
      case 'warning':
        return { bg: '#FFF3E0', border: '#FF9800', text: '#E65100' };
      case 'info':
        return { bg: '#E3F2FD', border: '#2196F3', text: '#1565C0' };
    }
  };

  const renderWarningBanners = () => {
    if (warningBanners.length === 0) {
      return null;
    }

    return (
      <Animated.View style={[styles.warningBannersContainer, { opacity: fadeAnim }]}>
        {warningBanners.map((banner) => {
          const bannerColors = getBannerColor(banner.type);
          return (
            <View
              key={banner.id}
              style={[
                styles.warningBanner,
                { backgroundColor: bannerColors.bg, borderColor: bannerColors.border }
              ]}
            >
              <View style={styles.warningBannerContent}>
                <View style={styles.warningBannerHeader}>
                  <Text style={[styles.warningBannerTitle, { color: bannerColors.text }]}>
                    {banner.title}
                  </Text>
                  <TouchableOpacity
                    onPress={() => removeWarningBanner(banner.id)}
                    style={styles.warningBannerClose}
                  >
                    <IconSymbol name="xmark.circle.fill" size={24} color={bannerColors.text} />
                  </TouchableOpacity>
                </View>
                <Text style={[styles.warningBannerMessage, { color: bannerColors.text }]}>
                  {banner.message}
                </Text>
              </View>
            </View>
          );
        })}
      </Animated.View>
    );
  };

  const renderMap = () => {
    if (steps.length === 0) {
      return null;
    }

    return (
      <Svg width={mapWidth} height={mapHeight} style={styles.svg}>
        <G>
          {routeSegments.length > 0 ? (
            routeSegments.map((segment, segIndex) => {
              const points = segment.points.map(p => {
                const { x, y } = latLngToSVG(p.latitude, p.longitude, bounds);
                return `${x},${y}`;
              }).join(' ');

              const strokeColor = segment.isRealRoute ? '#03A9F4' : '#FF5722';
              const strokeWidth = segment.isRealRoute ? '3' : '2';
              const strokeDasharray = segment.isRealRoute ? undefined : '5,5';

              return (
                <Polyline
                  key={`segment-${segIndex}`}
                  points={points}
                  fill="none"
                  stroke={strokeColor}
                  strokeWidth={strokeWidth}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeDasharray={strokeDasharray}
                />
              );
            })
          ) : (
            steps.slice(0, -1).map((step, index) => {
              const start = latLngToSVG(step.Latitude, step.Longitude, bounds);
              const end = latLngToSVG(steps[index + 1].Latitude, steps[index + 1].Longitude, bounds);

              return (
                <Line
                  key={`line-${index}`}
                  x1={start.x}
                  y1={start.y}
                  x2={end.x}
                  y2={end.y}
                  stroke="#FF5722"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeDasharray="5,5"
                />
              );
            })
          )}

          {steps.map((step, index) => {
            const { x, y } = latLngToSVG(step.Latitude, step.Longitude, bounds);
            const color = getMarkerColor(step.ActionAmount);
            const isSelected = selectedStep === index;
            const radius = isSelected ? 24 : 20;
            
            // Extract just the number from StationID (e.g., "1175" from station ID)
            const stationNumber = step.StationID.toString();
            // Adjust font size based on number length
            const fontSize = stationNumber.length > 4 ? "9" : stationNumber.length > 3 ? "10" : "12";

            return (
              <G key={`marker-${index}`}>
                <Circle
                  cx={x}
                  cy={y}
                  r={radius + 2}
                  fill="white"
                  onPress={() => setSelectedStep(index)}
                />
                <Circle
                  cx={x}
                  cy={y}
                  r={radius}
                  fill={color}
                  onPress={() => setSelectedStep(index)}
                />
                <SvgText
                  x={x}
                  y={y + 4}
                  fontSize={isSelected ? (fontSize === "9" ? "10" : fontSize === "10" ? "11" : "13") : fontSize}
                  fontWeight="bold"
                  fill="white"
                  textAnchor="middle"
                  onPress={() => setSelectedStep(index)}
                >
                  {stationNumber}
                </SvgText>
              </G>
            );
          })}
        </G>
      </Svg>
    );
  };

  if (isLoadingPermission) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>경로 지도</Text>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <IconSymbol name="xmark" size={24} color={colors.text} />
          </TouchableOpacity>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>위치 권한 확인 중...</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>경로 지도</Text>
        <TouchableOpacity onPress={onClose} style={styles.closeButton}>
          <IconSymbol name="xmark" size={24} color={colors.text} />
        </TouchableOpacity>
      </View>

      {renderWarningBanners()}

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>
              📍 경로 시각화 ({steps.length}개 정류장)
            </Text>
          </View>
          
          <View style={styles.mapContainer}>
            {renderMap()}
            
            {isLoadingRoutes && (
              <View style={styles.loadingOverlay}>
                <ActivityIndicator size="large" color={colors.primary} />
                <Text style={styles.loadingText}>
                  실제 도로 경로 로딩 중...
                </Text>
                <Text style={styles.loadingSubtext}>
                  구간 {loadingProgress.current}/{loadingProgress.total}
                </Text>
                <Text style={styles.loadingNote}>
                  OpenRouteService API 사용 중
                </Text>
                <Text style={styles.loadingNote}>
                  {loadingProgress.total > 0 && 
                    `예상 대기 시간: ${Math.ceil((loadingProgress.total - loadingProgress.current) * 2)}초`
                  }
                </Text>
              </View>
            )}
          </View>
          
          <View style={styles.mapInfoContainer}>
            {routeSegments.length > 0 ? (
              realRoutesCount === 0 ? (
                <View style={styles.warningBox}>
                  <Text style={styles.warningTitle}>⚠️ 경고: 모든 경로가 직선입니다</Text>
                  <Text style={styles.warningText}>
                    OpenRouteService API가 작동하지 않습니다.
                  </Text>
                </View>
              ) : realRoutesCount < routeSegments.length ? (
                <View style={styles.warningBox}>
                  <Text style={styles.warningTitle}>⚠️ 일부 경로가 직선입니다</Text>
                  <Text style={styles.warningText}>
                    {routeSegments.length - realRoutesCount}개 경로가 실패했습니다.{'\n'}
                    빨간색 점선 = 직선, 파란색 실선 = 실제 경로
                  </Text>
                </View>
              ) : (
                <Text style={styles.mapNote}>
                  ✓ SVG 기반 경로 시각화 + ORS 실제 경로
                </Text>
              )
            ) : isLoadingRoutes ? (
              <Text style={styles.mapNote}>
                ⏳ 실제 도로 경로 로딩 중...
              </Text>
            ) : (
              <Text style={styles.mapNote}>
                ⚠️ 경로를 불러오는 중입니다...
              </Text>
            )}
            
            {routeSegments.length > 0 && (
              <>
                <View style={styles.routeStats}>
                  <View style={styles.statItem}>
                    <Text style={styles.statLabel}>총 거리</Text>
                    <Text style={styles.statValue}>
                      {(totalDistance / 1000).toFixed(2)} km
                    </Text>
                  </View>
                  <View style={styles.statItem}>
                    <Text style={styles.statLabel}>예상 시간</Text>
                    <Text style={styles.statValue}>
                      {Math.round(totalDuration / 60)} 분
                    </Text>
                  </View>
                </View>
                <Text style={styles.debugInfo}>
                  🔍 {routeSegments.length}개 세그먼트 | 
                  ✅ {realRoutesCount}개 실제 경로 | 
                  ⚠️ {routeSegments.length - realRoutesCount}개 직선
                </Text>
              </>
            )}
            
            <View style={styles.actionButtonsContainer}>
              {!isLoadingRoutes && routeSegments.length === 0 && (
                <TouchableOpacity
                  style={styles.retryButton}
                  onPress={loadActualRoutes}
                >
                  <IconSymbol name="arrow.clockwise" size={16} color="#ffffff" />
                  <Text style={styles.retryButtonText}>경로 다시 불러오기</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>

          <View style={styles.mapLegend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: '#4CAF50' }]} />
              <Text style={styles.legendText}>픽업</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: '#F44336' }]} />
              <Text style={styles.legendText}>배치</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: '#2196F3' }]} />
              <Text style={styles.legendText}>경유</Text>
            </View>
          </View>

          <View style={styles.routeLegend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendLine, { backgroundColor: '#03A9F4' }]} />
              <Text style={styles.legendText}>실제 경로</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendLine, { backgroundColor: '#FF5722', borderStyle: 'dashed' }]} />
              <Text style={styles.legendText}>직선 (API 실패)</Text>
            </View>
          </View>

          {selectedStep !== null && (
            <View style={styles.selectedStepCard}>
              <View style={styles.selectedStepHeader}>
                <Text style={styles.selectedStepTitle}>
                  대여소 #{steps[selectedStep].StationID}
                </Text>
                <TouchableOpacity onPress={() => setSelectedStep(null)}>
                  <IconSymbol name="xmark.circle.fill" size={24} color="#ffffff" />
                </TouchableOpacity>
              </View>
              <Text style={styles.selectedStepStation}>
                순서: {steps[selectedStep].Step}번째
              </Text>
              <Text style={styles.selectedStepAction}>
                {getActionText(steps[selectedStep].ActionAmount)}
              </Text>
              <View style={styles.selectedStepDetails}>
                <Text style={styles.selectedStepDetail}>
                  📍 위도: {steps[selectedStep].Latitude.toFixed(6)}
                </Text>
                <Text style={styles.selectedStepDetail}>
                  📍 경도: {steps[selectedStep].Longitude.toFixed(6)}
                </Text>
                <Text style={styles.selectedStepDetail}>
                  🚚 트럭 재고: {steps[selectedStep].TruckLoad_Before}대 → {steps[selectedStep].TruckLoad_After}대
                </Text>
                {routeSegments[selectedStep] && (
                  <>
                    <Text style={styles.selectedStepDetail}>
                      🛣️ 다음 구간: {(routeSegments[selectedStep].distance / 1000).toFixed(2)} km, {Math.round(routeSegments[selectedStep].duration / 60)} 분
                    </Text>
                    <Text style={[
                      styles.selectedStepDetail,
                      { color: routeSegments[selectedStep].isRealRoute ? '#ffffff' : '#FFE082' }
                    ]}>
                      {routeSegments[selectedStep].isRealRoute ? '✅ 실제 경로' : '⚠️ 직선 경로'}
                    </Text>
                  </>
                )}
              </View>
            </View>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📋 상세 경로</Text>
          {steps.map((step, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.stepCard,
                selectedStep === index && styles.stepCardSelected
              ]}
              onPress={() => setSelectedStep(index)}
            >
              <View style={styles.stepHeader}>
                <View
                  style={[
                    styles.stepNumber,
                    { backgroundColor: getMarkerColor(step.ActionAmount) },
                  ]}
                >
                  <Text style={styles.stepNumberText}>{step.StationID}</Text>
                </View>
                <View style={styles.stepInfo}>
                  <Text style={styles.stepStation}>순서: {step.Step}번째</Text>
                  <Text style={styles.stepCluster}>
                    클러스터: {step.ClusterID}
                  </Text>
                </View>
                <View style={styles.stepAction}>
                  <Text
                    style={[
                      styles.stepActionText,
                      { color: getMarkerColor(step.ActionAmount) },
                    ]}
                  >
                    {getActionText(step.ActionAmount)}
                  </Text>
                </View>
              </View>

              <View style={styles.stepDetails}>
                <View style={styles.detailRow}>
                  <IconSymbol
                    name="location.fill"
                    size={16}
                    color={colors.textSecondary}
                  />
                  <Text style={styles.detailText}>
                    위도: {step.Latitude.toFixed(6)}, 경도:{' '}
                    {step.Longitude.toFixed(6)}
                  </Text>
                </View>

                <View style={styles.detailRow}>
                  <IconSymbol
                    name="cube.box.fill"
                    size={16}
                    color={colors.textSecondary}
                  />
                  <Text style={styles.detailText}>
                    트럭 재고: {step.TruckLoad_Before}대 → {step.TruckLoad_After}
                    대
                  </Text>
                </View>

                {routeSegments[index] && (
                  <>
                    <View style={styles.detailRow}>
                      <IconSymbol
                        name="arrow.right"
                        size={16}
                        color={colors.textSecondary}
                      />
                      <Text style={styles.detailText}>
                        다음 구간: {(routeSegments[index].distance / 1000).toFixed(2)} km, {' '}
                        {Math.round(routeSegments[index].duration / 60)} 분
                      </Text>
                    </View>
                    <View style={styles.detailRow}>
                      <IconSymbol
                        name={routeSegments[index].isRealRoute ? "checkmark.circle.fill" : "exclamationmark.triangle.fill"}
                        size={16}
                        color={routeSegments[index].isRealRoute ? '#4CAF50' : '#FF5722'}
                      />
                      <Text style={[
                        styles.detailText,
                        { color: routeSegments[index].isRealRoute ? '#4CAF50' : '#FF5722' }
                      ]}>
                        {routeSegments[index].isRealRoute ? '실제 경로' : '직선 경로 (API 실패)'}
                      </Text>
                    </View>
                  </>
                )}
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 요약</Text>
          <View style={styles.summaryCard}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>총 정류장 수</Text>
              <Text style={styles.summaryValue}>{steps.length}개</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>총 재배치량</Text>
              <Text style={styles.summaryValue}>
                {steps.reduce((sum, step) => sum + Math.abs(step.ActionAmount), 0)}
                대
              </Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>픽업 작업</Text>
              <Text style={[styles.summaryValue, { color: '#4CAF50' }]}>
                {steps.filter(s => s.ActionAmount > 0).length}회
              </Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>배치 작업</Text>
              <Text style={[styles.summaryValue, { color: '#F44336' }]}>
                {steps.filter(s => s.ActionAmount < 0).length}회
              </Text>
            </View>
            {routeSegments.length > 0 && (
              <>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>총 이동 거리</Text>
                  <Text style={styles.summaryValue}>
                    {(totalDistance / 1000).toFixed(2)} km
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>예상 소요 시간</Text>
                  <Text style={styles.summaryValue}>
                    {Math.round(totalDuration / 60)} 분
                  </Text>
                </View>
                <View style={[styles.summaryRow, { borderBottomWidth: 0 }]}>
                  <Text style={styles.summaryLabel}>실제 경로 / 직선</Text>
                  <Text style={styles.summaryValue}>
                    {realRoutesCount} / {routeSegments.length - realRoutesCount}
                  </Text>
                </View>
              </>
            )}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ℹ️ 지도 정보</Text>
          <View style={styles.infoCard}>
            <Text style={styles.infoCardText}>
              ✓ React Native SVG 기반 경로 시각화
            </Text>
            <Text style={styles.infoCardStep}>
              • WebView 없이 네이티브 렌더링
            </Text>
            <Text style={styles.infoCardStep}>
              • OpenRouteService API로 실제 경로 계산
            </Text>
            <Text style={styles.infoCardStep}>
              • 자전거 경로 최적화 (cycling-regular)
            </Text>
            <Text style={styles.infoCardStep}>
              • 실시간 거리 및 시간 계산
            </Text>
            <Text style={styles.infoCardStep}>
              • 원 안에 대여소 번호 표시
            </Text>
            <Text style={styles.infoCardNote}>
              💡 마커를 탭하여 상세 정보를 확인하세요
            </Text>
            <Text style={styles.infoCardNote}>
              🚴 OpenRouteService © HeiGIT
            </Text>
            {realRoutesCount === 0 && routeSegments.length > 0 && (
              <>
                <Text style={[styles.infoCardNote, { color: '#FF5722', fontWeight: 'bold', marginTop: 16 }]}>
                  ⚠️ 경고: 모든 경로가 직선입니다.
                </Text>
                <Text style={[styles.infoCardNote, { color: '#FF5722' }]}>
                  API 키 문제이거나 API가 인코딩된 폴리라인을 반환하고 있을 가능성이 높습니다.
                </Text>
              </>
            )}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'android' ? 48 : 60,
    paddingBottom: 20,
    backgroundColor: colors.card,
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  closeButton: {
    padding: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textSecondary,
  },
  warningBannersContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  warningBanner: {
    borderRadius: 12,
    borderWidth: 2,
    marginBottom: 12,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
    elevation: 4,
  },
  warningBannerContent: {
    padding: 16,
  },
  warningBannerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  warningBannerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
    marginRight: 12,
  },
  warningBannerClose: {
    padding: 4,
  },
  warningBannerMessage: {
    fontSize: 14,
    lineHeight: 22,
  },
  content: {
    flex: 1,
  },
  section: {
    padding: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  mapContainer: {
    backgroundColor: colors.card,
    borderRadius: 12,
    overflow: 'hidden',
    height: 400,
    marginBottom: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  svg: {
    backgroundColor: '#f5f5f5',
  },
  mapLegend: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 16,
    paddingTop: 16,
    paddingHorizontal: 16,
    backgroundColor: colors.card,
    borderRadius: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
    paddingBottom: 16,
  },
  routeLegend: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 12,
    paddingTop: 16,
    paddingHorizontal: 16,
    backgroundColor: colors.card,
    borderRadius: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
    paddingBottom: 16,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendColor: {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginRight: 8,
  },
  legendLine: {
    width: 24,
    height: 3,
    marginRight: 8,
  },
  legendText: {
    fontSize: 14,
    color: colors.text,
  },
  mapInfoContainer: {
    marginTop: 8,
  },
  mapNote: {
    fontSize: 14,
    color: colors.text,
    textAlign: 'center',
    marginBottom: 8,
    fontWeight: '600',
  },
  warningBox: {
    backgroundColor: '#FFF3E0',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#FF9800',
  },
  warningTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#E65100',
    marginBottom: 8,
  },
  warningText: {
    fontSize: 14,
    color: '#E65100',
    lineHeight: 20,
  },
  debugInfo: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 8,
    fontStyle: 'italic',
  },
  actionButtonsContainer: {
    marginTop: 12,
    gap: 8,
  },
  retryButton: {
    backgroundColor: colors.primary,
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  retryButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginLeft: 8,
  },
  routeStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  statItem: {
    alignItems: 'center',
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 4,
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.primary,
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    zIndex: 1000,
  },
  loadingSubtext: {
    marginTop: 8,
    fontSize: 14,
    color: colors.textSecondary,
  },
  loadingNote: {
    marginTop: 12,
    fontSize: 12,
    color: colors.textSecondary,
    fontStyle: 'italic',
  },
  selectedStepCard: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
    boxShadow: '0px 4px 12px rgba(3, 169, 244, 0.3)',
    elevation: 4,
  },
  selectedStepHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  selectedStepTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  selectedStepStation: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  selectedStepAction: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 12,
  },
  selectedStepDetails: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.3)',
    paddingTop: 12,
  },
  selectedStepDetail: {
    fontSize: 14,
    color: '#ffffff',
    marginBottom: 6,
  },
  stepCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  stepCardSelected: {
    borderWidth: 2,
    borderColor: colors.primary,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  stepNumber: {
    minWidth: 50,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    paddingHorizontal: 8,
  },
  stepNumberText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  stepInfo: {
    flex: 1,
  },
  stepStation: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
  },
  stepCluster: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  stepAction: {
    alignItems: 'flex-end',
  },
  stepActionText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  stepDetails: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: colors.background,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  detailText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginLeft: 8,
  },
  summaryCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.background,
  },
  summaryLabel: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.primary,
  },
  infoCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  infoCardText: {
    fontSize: 14,
    color: colors.text,
    marginBottom: 12,
    lineHeight: 20,
    fontWeight: '600',
  },
  infoCardStep: {
    fontSize: 14,
    color: colors.text,
    marginBottom: 8,
    paddingLeft: 8,
  },
  infoCardNote: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 12,
    fontStyle: 'italic',
  },
});
