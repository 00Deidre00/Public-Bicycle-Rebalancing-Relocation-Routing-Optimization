
import { colors } from '@/styles/commonStyles';
import React, { useState, useEffect } from 'react';
import * as Location from 'expo-location';
import { IconSymbol } from '@/components/IconSymbol';
import {
  View,
  Text,
  StyleSheet,
  Platform,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from 'react-native';
import { RouteStep } from '@/types/RouteData';

// Only import react-native-maps on native platforms
let MapView: any;
let Marker: any;
let Polyline: any;
let PROVIDER_GOOGLE: any;

if (Platform.OS !== 'web') {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Maps = require('react-native-maps');
    MapView = Maps.default;
    Marker = Maps.Marker;
    Polyline = Maps.Polyline;
    PROVIDER_GOOGLE = Maps.PROVIDER_GOOGLE;
  } catch (error) {
    console.log('react-native-maps not available:', error);
  }
}

interface RouteMapViewProps {
  steps: RouteStep[];
  onClose: () => void;
}

const RouteMapView: React.FC<RouteMapViewProps> = ({ steps, onClose }) => {
  const [currentLocation, setCurrentLocation] = useState<Location.LocationObject | null>(null);
  const [hasLocationPermission, setHasLocationPermission] = useState(false);

  useEffect(() => {
    requestLocationPermission();
  }, []);

  const requestLocationPermission = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        setHasLocationPermission(true);
        const location = await Location.getCurrentPositionAsync({});
        setCurrentLocation(location);
        console.log('Current location:', location);
      } else {
        console.log('Location permission denied');
      }
    } catch (error) {
      console.log('Error requesting location permission:', error);
    }
  };

  const getInitialRegion = () => {
    if (steps.length === 0) return null;
    
    const firstStep = steps[0];
    return {
      latitude: firstStep.Latitude,
      longitude: firstStep.Longitude,
      latitudeDelta: 0.05,
      longitudeDelta: 0.05,
    };
  };

  const getMarkerColor = (actionAmount: number): string => {
    if (actionAmount > 0) return '#4CAF50'; // Green for pickup
    if (actionAmount < 0) return '#F44336'; // Red for drop-off
    return '#2196F3'; // Blue for neutral
  };

  const coordinates = steps.map(step => ({
    latitude: step.Latitude,
    longitude: step.Longitude,
  }));

  const initialRegion = getInitialRegion();

  // Web fallback - show message instead of map
  if (Platform.OS === 'web') {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>경로 보기</Text>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <IconSymbol name="xmark" size={24} color={colors.text} />
          </TouchableOpacity>
        </View>

        <View style={styles.webMessageContainer}>
          <IconSymbol name="map" size={64} color={colors.primary} />
          <Text style={styles.webMessageTitle}>지도는 모바일에서만 사용 가능합니다</Text>
          <Text style={styles.webMessageSubtitle}>
            iOS 또는 Android 기기에서 앱을 실행하여 실제 지도와 경로를 확인하세요.
          </Text>
          <Text style={styles.webMessageNote}>
            Natively는 웹에서 react-native-maps를 지원하지 않습니다.
          </Text>
        </View>

        <ScrollView style={styles.stepsList}>
          <Text style={styles.stepsTitle}>경로 단계:</Text>
          {steps.map((step, index) => (
            <View key={index} style={styles.stepItem}>
              <View style={[
                styles.stepNumber,
                { backgroundColor: getMarkerColor(step.ActionAmount) }
              ]}>
                <Text style={styles.stepNumberText}>{step.Step}</Text>
              </View>
              <View style={styles.stepDetails}>
                <Text style={styles.stepStation}>
                  {step.StationID}
                </Text>
                <Text style={styles.stepCluster}>
                  클러스터: {step.ClusterID}
                </Text>
                <Text style={styles.stepCoordinates}>
                  위도: {step.Latitude.toFixed(6)}, 경도: {step.Longitude.toFixed(6)}
                </Text>
                <View style={styles.stepActionRow}>
                  <Text style={[
                    styles.stepAction,
                    step.ActionAmount > 0 && styles.stepActionPickup,
                    step.ActionAmount < 0 && styles.stepActionDropoff,
                  ]}>
                    {step.ActionAmount > 0 ? '픽업' : step.ActionAmount < 0 ? '배달' : '이동'}: {Math.abs(step.ActionAmount)}대
                  </Text>
                  <Text style={styles.stepLoad}>
                    적재량: {step.TruckLoad_Before} → {step.TruckLoad_After}
                  </Text>
                </View>
              </View>
            </View>
          ))}
        </ScrollView>
      </View>
    );
  }

  // Native platforms - show actual map
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>경로 보기</Text>
        <TouchableOpacity onPress={onClose} style={styles.closeButton}>
          <IconSymbol name="xmark" size={24} color={colors.text} />
        </TouchableOpacity>
      </View>

      <View style={styles.mapContainer}>
        {initialRegion && MapView ? (
          <MapView
            style={styles.map}
            initialRegion={initialRegion}
            provider={PROVIDER_GOOGLE}
            showsUserLocation={hasLocationPermission}
            showsMyLocationButton={hasLocationPermission}
          >
            <Polyline
              coordinates={coordinates}
              strokeColor={colors.primary}
              strokeWidth={4}
            />
            
            {steps.map((step, index) => (
              <Marker
                key={index}
                coordinate={{
                  latitude: step.Latitude,
                  longitude: step.Longitude,
                }}
                pinColor={getMarkerColor(step.ActionAmount)}
                title={`${step.Step}. ${step.StationID}`}
                description={`작업: ${step.ActionAmount > 0 ? '픽업' : '배달'} ${Math.abs(step.ActionAmount)}대 | 적재량: ${step.TruckLoad_After}`}
              />
            ))}
          </MapView>
        ) : (
          <View style={styles.noMapContainer}>
            <Text style={styles.noMapText}>지도를 불러올 수 없습니다</Text>
          </View>
        )}
      </View>

      <ScrollView style={styles.stepsList}>
        <Text style={styles.stepsTitle}>경로 단계:</Text>
        {steps.map((step, index) => (
          <View key={index} style={styles.stepItem}>
            <View style={[
              styles.stepNumber,
              { backgroundColor: getMarkerColor(step.ActionAmount) }
            ]}>
              <Text style={styles.stepNumberText}>{step.Step}</Text>
            </View>
            <View style={styles.stepDetails}>
              <Text style={styles.stepStation}>
                {step.StationID}
              </Text>
              <Text style={styles.stepCluster}>
                클러스터: {step.ClusterID}
              </Text>
              <Text style={styles.stepCoordinates}>
                위도: {step.Latitude.toFixed(6)}, 경도: {step.Longitude.toFixed(6)}
              </Text>
              <View style={styles.stepActionRow}>
                <Text style={[
                  styles.stepAction,
                  step.ActionAmount > 0 && styles.stepActionPickup,
                  step.ActionAmount < 0 && styles.stepActionDropoff,
                ]}>
                  {step.ActionAmount > 0 ? '픽업' : step.ActionAmount < 0 ? '배달' : '이동'}: {Math.abs(step.ActionAmount)}대
                </Text>
                <Text style={styles.stepLoad}>
                  적재량: {step.TruckLoad_Before} → {step.TruckLoad_After}
                </Text>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 60,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.card,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
  },
  closeButton: {
    padding: 8,
  },
  mapContainer: {
    height: Dimensions.get('window').height * 0.4,
    backgroundColor: colors.card,
  },
  map: {
    width: '100%',
    height: '100%',
  },
  noMapContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.card,
  },
  noMapText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  webMessageContainer: {
    height: Dimensions.get('window').height * 0.4,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: 32,
  },
  webMessageTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 24,
    textAlign: 'center',
  },
  webMessageSubtitle: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 12,
    textAlign: 'center',
    lineHeight: 24,
  },
  webMessageNote: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 8,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  stepsList: {
    flex: 1,
    padding: 16,
  },
  stepsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  stepItem: {
    flexDirection: 'row',
    marginBottom: 16,
    padding: 12,
    backgroundColor: colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  stepNumber: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  stepNumberText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  stepDetails: {
    flex: 1,
  },
  stepStation: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  stepCluster: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 4,
  },
  stepCoordinates: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 8,
  },
  stepActionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  stepAction: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
  },
  stepActionPickup: {
    color: '#4CAF50',
  },
  stepActionDropoff: {
    color: '#F44336',
  },
  stepLoad: {
    fontSize: 12,
    color: colors.textSecondary,
  },
});

export default RouteMapView;
