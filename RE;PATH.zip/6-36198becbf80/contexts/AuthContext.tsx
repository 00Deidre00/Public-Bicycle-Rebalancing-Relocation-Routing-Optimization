
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Alert } from 'react-native';

interface User {
  email: string;
  name: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string, name: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is already logged in (simulated)
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Simulate API call
      console.log('Login attempt:', email);
      
      // Simple validation
      if (!email || !password) {
        Alert.alert('Error', 'Please enter email and password');
        return false;
      }

      if (password.length < 6) {
        Alert.alert('Error', 'Password must be at least 6 characters');
        return false;
      }

      // Simulate successful login
      setUser({ email, name: email.split('@')[0] });
      return true;
    } catch (error) {
      console.error('Login error:', error);
      Alert.alert('Error', 'Login failed. Please try again.');
      return false;
    }
  };

  const signup = async (email: string, password: string, name: string): Promise<boolean> => {
    try {
      console.log('Signup attempt:', email, name);
      
      // Simple validation
      if (!email || !password || !name) {
        Alert.alert('Error', 'Please fill in all fields');
        return false;
      }

      if (password.length < 6) {
        Alert.alert('Error', 'Password must be at least 6 characters');
        return false;
      }

      if (!email.includes('@')) {
        Alert.alert('Error', 'Please enter a valid email');
        return false;
      }

      // Simulate successful signup
      setUser({ email, name });
      Alert.alert('Success', 'Account created successfully!');
      return true;
    } catch (error) {
      console.error('Signup error:', error);
      Alert.alert('Error', 'Signup failed. Please try again.');
      return false;
    }
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
