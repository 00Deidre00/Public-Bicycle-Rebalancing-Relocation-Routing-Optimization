
export interface RouteStep {
  Step: number;
  ClusterID: string;
  StationID: string;
  Latitude: number;
  Longitude: number;
  ActionAmount: number;
  TruckLoad_Before: number;
  TruckLoad_After: number;
}

export interface ParsedRoute {
  steps: RouteStep[];
  totalDistance: number;
  estimatedTime: number;
  redistributionAmount: number;
}
