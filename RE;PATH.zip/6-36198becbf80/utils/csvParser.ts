
import { Platform } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Network from 'expo-network';

export interface CSVRow {
  [key: string]: string;
}

/**
 * Parse CSV text into an array of objects
 * Handles various CSV formats including quoted fields and different delimiters
 * @param csvText The CSV text to parse
 * @returns Array of objects where keys are column headers
 */
export function parseCSV(csvText: string): CSVRow[] {
  console.log('=== Starting CSV parsing ===');
  console.log('CSV text length:', csvText.length);
  console.log('First 500 characters:', csvText.substring(0, 500));
  
  if (!csvText || csvText.trim().length === 0) {
    console.error('CSV text is empty or null');
    return [];
  }

  // Normalize line endings
  const normalizedText = csvText.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const lines = normalizedText.trim().split('\n');
  
  console.log('Total lines:', lines.length);
  
  if (lines.length === 0) {
    console.error('CSV has no lines after splitting');
    return [];
  }

  // Parse CSV line with support for quoted fields
  const parseLine = (line: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      const nextChar = line[i + 1];
      
      if (char === '"') {
        if (inQuotes && nextChar === '"') {
          // Escaped quote
          current += '"';
          i++; // Skip next quote
        } else {
          // Toggle quote state
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        // Field separator
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    // Add last field
    result.push(current.trim());
    
    return result;
  };

  // Get headers from first line
  const headerLine = lines[0];
  console.log('Header line:', headerLine);
  
  const headers = parseLine(headerLine);
  console.log('CSV Headers:', headers);
  console.log('Number of headers:', headers.length);
  
  // Parse data rows
  const data: CSVRow[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) {
      console.log(`Skipping empty line at index ${i}`);
      continue;
    }
    
    const values = parseLine(line);
    
    // Skip rows that don't have enough values
    if (values.length < headers.length) {
      console.warn(`Row ${i} has fewer values (${values.length}) than headers (${headers.length}), skipping`);
      continue;
    }
    
    const row: CSVRow = {};
    
    headers.forEach((header, index) => {
      row[header] = values[index] || '';
    });
    
    data.push(row);
    
    // Log first few rows for debugging
    if (i <= 3) {
      console.log(`Row ${i}:`, JSON.stringify(row));
    }
  }
  
  console.log('Total rows parsed:', data.length);
  console.log('=== CSV parsing complete ===');
  
  return data;
}

/**
 * Check network connectivity before fetching
 */
async function checkNetworkConnectivity(): Promise<void> {
  try {
    console.log('Checking network connectivity...');
    const networkState = await Network.getNetworkStateAsync();
    
    console.log('Network state:', {
      type: networkState.type,
      isConnected: networkState.isConnected,
      isInternetReachable: networkState.isInternetReachable,
    });
    
    if (!networkState.isConnected) {
      throw new Error('인터넷에 연결되어 있지 않습니다. Wi-Fi 또는 모바일 데이터를 확인해주세요.');
    }
    
    if (networkState.isInternetReachable === false) {
      throw new Error('인터넷에 접근할 수 없습니다. 네트워크 연결을 확인해주세요.');
    }
    
    console.log('✓ Network connectivity check passed');
  } catch (error) {
    console.error('Network connectivity check failed:', error);
    throw error;
  }
}

/**
 * Fetch CSV using expo-file-system with improved error handling
 * This method downloads the file to local storage first, then reads it
 * Only works on native platforms (iOS/Android)
 */
async function fetchWithFileSystem(url: string): Promise<string> {
  console.log('Using expo-file-system for download...');
  
  if (Platform.OS === 'web') {
    throw new Error('FileSystem.downloadAsync is not available on web platform');
  }
  
  try {
    // Create a temporary file path
    const fileUri = FileSystem.cacheDirectory + 'temp_csv_' + Date.now() + '.csv';
    console.log('Temporary file path:', fileUri);
    
    // Download the file with custom headers
    console.log('Starting download with FileSystem.downloadAsync...');
    const downloadResult = await FileSystem.downloadAsync(
      url,
      fileUri,
      {
        headers: {
          'Accept': 'text/csv, text/plain, application/csv, */*',
          'User-Agent': 'Mozilla/5.0 (compatible; RE:PATH App)',
        },
      }
    );
    
    console.log('Download result:', {
      uri: downloadResult.uri,
      status: downloadResult.status,
      headers: downloadResult.headers,
    });
    
    if (downloadResult.status !== 200) {
      // Check if we got an HTML error page
      try {
        const content = await FileSystem.readAsStringAsync(downloadResult.uri);
        if (content.includes('<!DOCTYPE') || content.includes('<html')) {
          throw new Error(
            `Google Cloud Storage 접근 오류!\n\n` +
            `파일이 공개로 설정되어 있지 않습니다.\n\n` +
            `해결 방법:\n` +
            `1. Google Cloud Console에서 버킷 열기\n` +
            `2. 파일 선택 → 권한 탭\n` +
            `3. "액세스 권한 추가" 클릭\n` +
            `4. 주 구성원: "allUsers"\n` +
            `5. 역할: "Storage 객체 뷰어"\n` +
            `6. 저장 후 다시 시도`
          );
        }
      } catch (readError) {
        console.error('Error reading downloaded file:', readError);
      }
      
      throw new Error(`다운로드 실패! HTTP 상태 코드: ${downloadResult.status}`);
    }
    
    console.log('✓ File downloaded successfully');
    
    // Read the file content
    console.log('Reading file content...');
    const fileContent = await FileSystem.readAsStringAsync(downloadResult.uri);
    
    console.log('✓ File content read successfully');
    console.log('Content length:', fileContent.length);
    
    // Validate content is CSV, not HTML
    const trimmedContent = fileContent.trim();
    if (trimmedContent.startsWith('<!DOCTYPE') || 
        trimmedContent.startsWith('<html') || 
        trimmedContent.startsWith('<?xml')) {
      throw new Error(
        `CSV 파일 대신 HTML 페이지를 받았습니다.\n\n` +
        `이는 파일이 공개로 설정되지 않았음을 의미합니다.\n\n` +
        `Google Cloud Storage 버킷 설정을 확인해주세요.`
      );
    }
    
    // Clean up: delete the temporary file
    try {
      await FileSystem.deleteAsync(fileUri, { idempotent: true });
      console.log('✓ Temporary file deleted');
    } catch (deleteError) {
      console.warn('Failed to delete temporary file:', deleteError);
    }
    
    return fileContent;
  } catch (error: any) {
    console.error('FileSystem download error:', error);
    
    // Provide more specific error messages
    if (error.message && error.message.includes('Network request failed')) {
      throw new Error(
        `네트워크 요청 실패!\n\n` +
        `가능한 원인:\n` +
        `1. 인터넷 연결 불안정\n` +
        `2. Google Cloud Storage 서버 접근 불가\n` +
        `3. 방화벽 또는 VPN 차단\n\n` +
        `다른 네트워크(Wi-Fi/모바일 데이터)로 시도해보세요.`
      );
    }
    
    throw error;
  }
}

/**
 * Fetch CSV using XMLHttpRequest as a fallback
 */
function fetchWithXHR(url: string, timeoutMs: number = 30000): Promise<string> {
  return new Promise((resolve, reject) => {
    console.log('Using XMLHttpRequest for fetch...');
    
    const xhr = new XMLHttpRequest();
    
    // Set timeout
    xhr.timeout = timeoutMs;
    
    xhr.onload = () => {
      console.log('XHR onload - status:', xhr.status);
      console.log('XHR response type:', xhr.responseType);
      console.log('XHR response length:', xhr.responseText?.length || 0);
      
      if (xhr.status >= 200 && xhr.status < 300) {
        const responseText = xhr.responseText;
        
        // Check if we got HTML instead of CSV
        const trimmed = responseText.trim();
        if (trimmed.startsWith('<!DOCTYPE') || 
            trimmed.startsWith('<html') || 
            trimmed.startsWith('<?xml')) {
          console.error('XHR received HTML instead of CSV');
          reject(new Error(
            `CSV 파일 대신 HTML을 받았습니다.\n\n` +
            `파일이 공개로 설정되어 있지 않습니다.`
          ));
          return;
        }
        
        console.log('✓ XHR request successful');
        console.log('Response length:', responseText.length);
        resolve(responseText);
      } else {
        console.error('XHR request failed with status:', xhr.status);
        reject(new Error(`HTTP 오류! 상태 코드: ${xhr.status}`));
      }
    };
    
    xhr.onerror = () => {
      console.error('XHR onerror triggered');
      reject(new Error('네트워크 오류가 발생했습니다. 인터넷 연결을 확인해주세요.'));
    };
    
    xhr.ontimeout = () => {
      console.error('XHR timeout triggered');
      reject(new Error(`요청 시간이 초과되었습니다 (${timeoutMs / 1000}초).`));
    };
    
    try {
      console.log('Opening XHR connection...');
      xhr.open('GET', url, true);
      
      // Set headers
      xhr.setRequestHeader('Accept', 'text/csv, text/plain, application/csv, */*');
      xhr.setRequestHeader('User-Agent', 'Mozilla/5.0 (compatible; RE:PATH App)');
      
      console.log('Sending XHR request...');
      xhr.send();
    } catch (error) {
      console.error('Error setting up XHR:', error);
      reject(error);
    }
  });
}

/**
 * Try to fetch using standard fetch API with better error handling
 */
async function fetchWithFetchAPI(url: string, timeoutMs: number = 30000): Promise<string> {
  console.log('Using standard Fetch API...');
  
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    console.log('⏱️ Fetch timeout - aborting request');
    controller.abort();
  }, timeoutMs);
  
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'text/csv, text/plain, application/csv, */*',
        'User-Agent': 'Mozilla/5.0 (compatible; RE:PATH App)',
      },
      signal: controller.signal,
      mode: 'cors', // Explicitly set CORS mode
    });
    
    clearTimeout(timeoutId);
    console.log('✓ Fetch completed');
    console.log('Response status:', response.status);
    console.log('Response headers:', JSON.stringify(Object.fromEntries(response.headers.entries())));
    
    if (!response.ok) {
      throw new Error(`HTTP 오류! 상태 코드: ${response.status}`);
    }
    
    const text = await response.text();
    console.log('✓ Response text read successfully');
    console.log('Text length:', text.length);
    
    // Check if we got HTML instead of CSV
    const trimmed = text.trim();
    if (trimmed.startsWith('<!DOCTYPE') || 
        trimmed.startsWith('<html') || 
        trimmed.startsWith('<?xml')) {
      throw new Error(
        `CSV 파일 대신 HTML을 받았습니다.\n\n` +
        `파일이 공개로 설정되어 있지 않습니다.`
      );
    }
    
    return text;
  } catch (error: any) {
    clearTimeout(timeoutId);
    
    if (error.name === 'AbortError') {
      throw new Error(`요청 시간 초과 (${timeoutMs / 1000}초)`);
    }
    
    throw error;
  }
}

/**
 * Fetch using CORS proxy for web platform
 * This is a workaround for CORS issues on web
 */
async function fetchWithCORSProxy(url: string, timeoutMs: number = 30000): Promise<string> {
  console.log('Using CORS proxy for web platform...');
  
  // Use a public CORS proxy
  const corsProxies = [
    `https://corsproxy.io/?${encodeURIComponent(url)}`,
    `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
  ];
  
  let lastError: Error | null = null;
  
  for (const proxyUrl of corsProxies) {
    try {
      console.log('Trying CORS proxy:', proxyUrl);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      
      const response = await fetch(proxyUrl, {
        method: 'GET',
        headers: {
          'Accept': 'text/csv, text/plain, application/csv, */*',
        },
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`HTTP 오류! 상태 코드: ${response.status}`);
      }
      
      const text = await response.text();
      console.log('✓ CORS proxy fetch successful');
      console.log('Text length:', text.length);
      
      // Validate content
      const trimmed = text.trim();
      if (trimmed.startsWith('<!DOCTYPE') || 
          trimmed.startsWith('<html') || 
          trimmed.startsWith('<?xml')) {
        throw new Error('Received HTML instead of CSV');
      }
      
      return text;
    } catch (error: any) {
      console.error(`CORS proxy ${proxyUrl} failed:`, error.message);
      lastError = error;
      continue;
    }
  }
  
  throw lastError || new Error('All CORS proxies failed');
}

/**
 * Fetch and parse CSV from a URL with improved error handling
 * Uses multiple methods to try to fetch the CSV file
 * @param url The URL to fetch CSV from
 * @returns Parsed CSV data as array of objects
 */
export async function fetchAndParseCSV(url: string): Promise<CSVRow[]> {
  console.log('\n\n=== FETCH AND PARSE CSV STARTED ===');
  console.log('Timestamp:', new Date().toISOString());
  console.log('URL:', url);
  console.log('Platform:', Platform.OS);
  
  try {
    // Step 1: Check network connectivity
    console.log('\n--- Step 1: Checking network connectivity ---');
    await checkNetworkConnectivity();
    
    // Step 2: Validate URL
    console.log('\n--- Step 2: Validating URL ---');
    if (!url || url.trim().length === 0) {
      throw new Error('URL이 비어있습니다.');
    }
    
    try {
      new URL(url);
      console.log('✓ URL is valid');
    } catch (e) {
      throw new Error('유효하지 않은 URL입니다: ' + url);
    }
    
    // Step 3: Fetch CSV data using multiple methods
    console.log('\n--- Step 3: Fetching CSV data ---');
    let csvText: string;
    let fetchMethod = '';
    const errors: string[] = [];
    
    // For web platform, try CORS proxy first
    if (Platform.OS === 'web') {
      console.log('\n🌐 Web platform detected - trying CORS proxy first...');
      
      try {
        console.log('\n🔄 Method 1 (Web): Trying CORS proxy...');
        csvText = await fetchWithCORSProxy(url, 30000);
        fetchMethod = 'CORS proxy';
        console.log('✅ Fetch completed successfully via CORS proxy');
      } catch (corsError: any) {
        console.error('❌ CORS proxy failed:', corsError.message);
        errors.push(`CORS Proxy: ${corsError.message}`);
        
        // Try direct fetch as fallback
        try {
          console.log('\n🔄 Method 2 (Web): Trying direct fetch...');
          csvText = await fetchWithFetchAPI(url, 30000);
          fetchMethod = 'direct fetch (web)';
          console.log('✅ Fetch completed successfully via direct fetch');
        } catch (fetchError: any) {
          console.error('❌ Direct fetch failed:', fetchError.message);
          errors.push(`Direct Fetch: ${fetchError.message}`);
          
          // All web methods failed
          console.error('\n❌❌❌ ALL WEB FETCH METHODS FAILED ❌❌❌');
          
          throw new Error(
            `❌ CSV 파일을 가져올 수 없습니다 (웹 플랫폼)\n\n` +
            `시도한 방법:\n` +
            `1️⃣ CORS Proxy: ${errors[0]}\n` +
            `2️⃣ Direct Fetch: ${errors[1]}\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `🔧 해결 방법:\n\n` +
            `웹 브라우저에서는 CORS 정책으로 인해\n` +
            `Google Cloud Storage 파일에 직접\n` +
            `접근하기 어려울 수 있습니다.\n\n` +
            `권장 사항:\n` +
            `1. 모바일 앱(iOS/Android)에서 사용\n` +
            `2. Google Cloud Storage CORS 설정:\n` +
            `   - gsutil cors set cors.json gs://버킷명\n` +
            `   - cors.json 예시:\n` +
            `   [{\n` +
            `     "origin": ["*"],\n` +
            `     "method": ["GET"],\n` +
            `     "responseHeader": ["*"],\n` +
            `     "maxAgeSeconds": 3600\n` +
            `   }]\n\n` +
            `3. 파일을 공개 URL로 제공\n` +
            `4. 백엔드 서버를 통해 프록시`
          );
        }
      }
    } else {
      // Native platform (iOS/Android)
      console.log('\n📱 Native platform detected - using native methods...');
      
      // Method 1: Try expo-file-system (best for native)
      try {
        console.log('\n🔄 Method 1 (Native): Trying expo-file-system...');
        csvText = await fetchWithFileSystem(url);
        fetchMethod = 'expo-file-system';
        console.log('✅ Fetch completed successfully via expo-file-system');
      } catch (fileSystemError: any) {
        console.error('❌ FileSystem fetch failed:', fileSystemError.message);
        errors.push(`FileSystem: ${fileSystemError.message}`);
        
        // Method 2: Try XMLHttpRequest
        try {
          console.log('\n🔄 Method 2 (Native): Trying XMLHttpRequest...');
          csvText = await fetchWithXHR(url, 30000);
          fetchMethod = 'XMLHttpRequest';
          console.log('✅ Fetch completed successfully via XHR');
        } catch (xhrError: any) {
          console.error('❌ XHR fetch failed:', xhrError.message);
          errors.push(`XMLHttpRequest: ${xhrError.message}`);
          
          // Method 3: Try standard fetch as last resort
          try {
            console.log('\n🔄 Method 3 (Native): Trying standard fetch API...');
            csvText = await fetchWithFetchAPI(url, 30000);
            fetchMethod = 'fetch API';
            console.log('✅ Fetch completed successfully via Fetch API');
          } catch (fetchError: any) {
            console.error('❌ Fetch API failed:', fetchError.message);
            errors.push(`Fetch API: ${fetchError.message}`);
            
            // All native methods failed
            console.error('\n❌❌❌ ALL NATIVE FETCH METHODS FAILED ❌❌❌');
            console.error('Errors:', errors);
            
            // Provide comprehensive error message
            throw new Error(
              `❌ CSV 파일을 가져올 수 없습니다.\n\n` +
              `모든 다운로드 방법이 실패했습니다:\n\n` +
              `1️⃣ FileSystem 다운로드:\n${errors[0]}\n\n` +
              `2️⃣ XMLHttpRequest:\n${errors[1]}\n\n` +
              `3️⃣ Fetch API:\n${errors[2]}\n\n` +
              `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
              `🔧 해결 방법:\n\n` +
              `1. Google Cloud Console 접속\n` +
              `2. Storage → 버킷 선택\n` +
              `3. 파일 찾기 → 권한 탭\n` +
              `4. "액세스 권한 추가" 클릭\n` +
              `5. 주 구성원: allUsers\n` +
              `6. 역할: Storage 객체 뷰어\n` +
              `7. 저장 후 앱 재시작\n\n` +
              `또는:\n\n` +
              `• 다른 네트워크로 시도\n` +
              `• VPN 끄기\n` +
              `• 브라우저에서 URL 확인\n` +
              `• 파일이 "공개"인지 확인`
            );
          }
        }
      }
    }
    
    console.log(`\n✅ CSV fetched successfully using: ${fetchMethod}`);
    
    // Step 4: Validate response
    console.log('\n--- Step 4: Validating response ---');
    console.log('CSV text length:', csvText.length);
    console.log('CSV text type:', typeof csvText);
    
    if (!csvText || csvText.length === 0) {
      throw new Error('CSV 파일이 비어있습니다.');
    }
    
    console.log('First 1000 characters of CSV:');
    console.log(csvText.substring(0, 1000));
    
    // Step 5: Parse CSV
    console.log('\n--- Step 5: Parsing CSV text ---');
    const parsedData = parseCSV(csvText);
    
    console.log('✓ CSV parsed successfully');
    console.log('Total rows parsed:', parsedData.length);
    
    if (parsedData.length === 0) {
      throw new Error('CSV 파일에 데이터가 없습니다.\n\n헤더만 있고 데이터 행이 없습니다.');
    }
    
    // Step 6: Log sample data
    console.log('\n--- Step 6: Sample of parsed data ---');
    console.log('First row:', JSON.stringify(parsedData[0], null, 2));
    if (parsedData.length > 1) {
      console.log('Second row:', JSON.stringify(parsedData[1], null, 2));
    }
    
    console.log(`\n✅✅✅ FETCH AND PARSE CSV COMPLETED SUCCESSFULLY (via ${fetchMethod}) ✅✅✅\n\n`);
    return parsedData;
    
  } catch (error) {
    console.error('\n\n❌❌❌ ERROR IN FETCH AND PARSE CSV ❌❌❌');
    console.error('Timestamp:', new Date().toISOString());
    console.error('Error type:', error instanceof Error ? error.constructor.name : typeof error);
    console.error('Error message:', error instanceof Error ? error.message : String(error));
    console.error('Error stack:', error instanceof Error ? error.stack : 'No stack trace available');
    console.error('\n❌❌❌ FETCH AND PARSE CSV ERROR COMPLETE ❌❌❌\n\n');
    throw error;
  }
}
