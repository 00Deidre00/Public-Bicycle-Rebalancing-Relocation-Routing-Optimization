
export async function testOpenRouteServiceAPI(apiKey: string): Promise<{
  success: boolean;
  message: string;
  details?: any;
}> {
  console.log(`\n🧪 ========================================`);
  console.log(`🧪 TESTING OPENROUTESERVICE API`);
  console.log(`🧪 ========================================`);
  console.log(`🔑 API Key: ${apiKey.substring(0, 20)}...${apiKey.substring(apiKey.length - 10)}`);
  console.log(`🔑 API Key length: ${apiKey.length} characters`);
  
  // Use test coordinates from your CSV data (Seoul area)
  const testCoordinates = {
    start: [126.8497696, 37.55065918],  // First point from your CSV
    end: [126.8575363, 37.55437851],    // Second point from your CSV
  };
  
  console.log(`📍 Test coordinates (from your CSV data):`);
  console.log(`   Start: [${testCoordinates.start[0]}, ${testCoordinates.start[1]}] (longitude, latitude)`);
  console.log(`   End: [${testCoordinates.end[0]}, ${testCoordinates.end[1]}] (longitude, latitude)`);
  
  // Calculate expected distance
  const R = 6371000; // Earth's radius in meters
  const lat1 = testCoordinates.start[1];
  const lon1 = testCoordinates.start[0];
  const lat2 = testCoordinates.end[1];
  const lon2 = testCoordinates.end[0];
  
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * 
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const expectedDistance = R * c;
  
  console.log(`📏 Expected straight-line distance: ${(expectedDistance / 1000).toFixed(2)} km`);
  
  const url = 'https://api.openrouteservice.org/v2/directions/cycling-regular';
  console.log(`🌐 API URL: ${url}`);
  
  const requestBody = {
    coordinates: [testCoordinates.start, testCoordinates.end],
  };
  
  console.log(`📤 Request body:`, JSON.stringify(requestBody, null, 2));
  console.log(`📤 Coordinate format: [longitude, latitude]`);
  
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    console.log(`⏰ Aborting test request after 20 seconds`);
    controller.abort();
  }, 20000);
  
  try {
    console.log(`⏰ Sending test request...`);
    const startTime = Date.now();
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
        'Content-Type': 'application/json; charset=utf-8',
        'Authorization': apiKey,
      },
      body: JSON.stringify(requestBody),
      signal: controller.signal,
    });
    
    clearTimeout(timeoutId);
    
    const endTime = Date.now();
    const requestDuration = endTime - startTime;
    
    console.log(`⏱️ Request completed in ${requestDuration}ms (${(requestDuration / 1000).toFixed(2)}s)`);
    console.log(`📥 Response status: ${response.status} ${response.statusText}`);
    console.log(`📥 Response ok: ${response.ok}`);
    
    console.log(`📥 Response Headers:`);
    response.headers.forEach((value, key) => {
      console.log(`   ${key}: ${value}`);
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`❌ API test failed with status ${response.status}`);
      console.error(`❌ Error response:`, errorText);
      
      let errorDetails;
      try {
        errorDetails = JSON.parse(errorText);
        console.error(`❌ Error details:`, JSON.stringify(errorDetails, null, 2));
      } catch (e) {
        console.error(`❌ Could not parse error as JSON`);
      }
      
      console.log(`🧪 ========================================\n`);
      
      return {
        success: false,
        message: `API returned status ${response.status}: ${response.statusText}`,
        details: errorDetails || errorText,
      };
    }
    
    const responseText = await response.text();
    console.log(`📦 Raw response text (first 500 chars):`, responseText.substring(0, 500));
    
    let data;
    try {
      data = JSON.parse(responseText);
    } catch (e) {
      console.error(`❌ Failed to parse response as JSON`);
      console.error(`Response text:`, responseText);
      console.log(`🧪 ========================================\n`);
      
      return {
        success: false,
        message: 'Failed to parse API response as JSON',
        details: responseText,
      };
    }
    
    console.log(`📦 Response data keys:`, Object.keys(data).join(', '));
    console.log(`📦 Full response:`, JSON.stringify(data, null, 2));
    
    if (!data.routes || data.routes.length === 0) {
      console.error(`❌ No routes in response`);
      console.error(`Response:`, JSON.stringify(data, null, 2));
      console.log(`🧪 ========================================\n`);
      
      return {
        success: false,
        message: 'API returned no routes',
        details: data,
      };
    }
    
    const route = data.routes[0];
    console.log(`📦 Route keys:`, Object.keys(route).join(', '));
    console.log(`📦 Full route:`, JSON.stringify(route, null, 2));
    
    // Check geometry
    if (!route.geometry) {
      console.error(`❌ No geometry in route`);
      console.error(`Route:`, JSON.stringify(route, null, 2));
      console.log(`🧪 ========================================\n`);
      
      return {
        success: false,
        message: 'Route has no geometry data',
        details: route,
      };
    }
    
    console.log(`📦 Geometry type:`, typeof route.geometry);
    console.log(`📦 Geometry keys:`, Object.keys(route.geometry).join(', '));
    console.log(`📦 Geometry value:`, JSON.stringify(route.geometry, null, 2));
    
    // Check if geometry is a string (encoded polyline) or object
    if (typeof route.geometry === 'string') {
      console.log(`📦 Geometry is an ENCODED POLYLINE STRING`);
      console.log(`📦 Polyline length: ${route.geometry.length} characters`);
      console.log(`📦 First 100 chars: ${route.geometry.substring(0, 100)}`);
      
      // This is the issue! The API is returning an encoded polyline, not coordinates array
      console.log(`\n⚠️⚠️⚠️ FOUND THE PROBLEM! ⚠️⚠️⚠️`);
      console.log(`The API is returning geometry as an ENCODED POLYLINE, not a coordinates array!`);
      console.log(`You need to decode the polyline to get coordinates.`);
      console.log(`The app already has a decodePolyline function in routingService.ts`);
      
      const summary = route.summary || {};
      const distance = summary.distance || 0;
      const routeDuration = summary.duration || 0;
      
      console.log(`📏 Route distance: ${(distance / 1000).toFixed(2)} km`);
      console.log(`⏱️ Route duration: ${(routeDuration / 60).toFixed(1)} minutes`);
      
      console.log(`✅ API test successful! (but geometry needs decoding)`);
      console.log(`🧪 ========================================\n`);
      
      return {
        success: true,
        message: `API working! Got encoded polyline route with ${(distance / 1000).toFixed(2)}km, ${(routeDuration / 60).toFixed(1)}min.\n\n⚠️ Geometry is encoded polyline format, not coordinates array. The app needs to decode it.`,
        details: {
          distance,
          duration: routeDuration,
          geometryType: 'encoded_polyline',
          polylineLength: route.geometry.length,
          responseTime: requestDuration,
        },
      };
    }
    
    // Check coordinates
    if (!route.geometry.coordinates) {
      console.error(`❌ No coordinates property in geometry`);
      console.error(`Geometry:`, JSON.stringify(route.geometry, null, 2));
      console.log(`🧪 ========================================\n`);
      
      return {
        success: false,
        message: 'Geometry has no coordinates property',
        details: route.geometry,
      };
    }
    
    if (!Array.isArray(route.geometry.coordinates)) {
      console.error(`❌ Coordinates is not an array`);
      console.error(`Coordinates type:`, typeof route.geometry.coordinates);
      console.error(`Coordinates value:`, route.geometry.coordinates);
      console.log(`🧪 ========================================\n`);
      
      return {
        success: false,
        message: `Coordinates is not an array (type: ${typeof route.geometry.coordinates})`,
        details: route.geometry,
      };
    }
    
    const coordinates = route.geometry.coordinates;
    const pointsCount = coordinates.length;
    
    console.log(`📍 Coordinates array length: ${pointsCount}`);
    
    if (pointsCount > 0) {
      console.log(`📍 First coordinate:`, coordinates[0]);
      console.log(`📍 Last coordinate:`, coordinates[pointsCount - 1]);
      console.log(`📍 Sample (first 3):`, coordinates.slice(0, 3));
    }
    
    const distance = route.summary?.distance || 0;
    const routeDuration = route.summary?.duration || 0;
    
    console.log(`📏 Route distance: ${(distance / 1000).toFixed(2)} km`);
    console.log(`⏱️ Route duration: ${(routeDuration / 60).toFixed(1)} minutes`);
    console.log(`📍 Route points: ${pointsCount}`);
    
    if (pointsCount === 0) {
      console.error(`❌ CRITICAL: Coordinates array is EMPTY!`);
      console.error(`This means the API is returning a valid response structure but no actual route data.`);
      console.error(`\nPossible causes:`);
      console.error(`  1. API key doesn't have proper permissions`);
      console.error(`  2. API key is expired or quota exceeded`);
      console.error(`  3. Coordinates are outside the supported region`);
      console.error(`  4. API service is experiencing issues`);
      console.error(`\nAPI Response Summary:`);
      console.error(`  - Distance: ${distance}m`);
      console.error(`  - Duration: ${routeDuration}s`);
      console.error(`  - Points: ${pointsCount}`);
      console.error(`  - Geometry type: ${route.geometry.type}`);
      console.log(`🧪 ========================================\n`);
      
      return {
        success: false,
        message: `Geometry has no coordinates array (length is 0).\n\nAPI returned valid structure but empty route.\n\nThis usually means:\n• API key lacks permissions\n• API quota exceeded\n• Coordinates outside supported region\n\nDistance: ${(distance / 1000).toFixed(2)}km, Duration: ${(routeDuration / 60).toFixed(1)}min`,
        details: {
          distance,
          duration: routeDuration,
          pointsCount,
          responseTime: requestDuration,
          warning: 'Coordinates array exists but is empty - API key issue likely',
          geometry: route.geometry,
          fullRoute: route,
        },
      };
    }
    
    console.log(`✅ API test successful!`);
    console.log(`🧪 ========================================\n`);
    
    return {
      success: true,
      message: `API working correctly! Got route with ${pointsCount} points, ${(distance / 1000).toFixed(2)}km, ${(routeDuration / 60).toFixed(1)}min`,
      details: {
        distance,
        duration: routeDuration,
        pointsCount,
        responseTime: requestDuration,
        firstCoordinate: coordinates[0],
        lastCoordinate: coordinates[pointsCount - 1],
      },
    };
  } catch (error) {
    clearTimeout(timeoutId);
    
    let errorMessage = 'Unknown error';
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        errorMessage = 'Request timed out after 20 seconds';
        console.error(`⏰ ${errorMessage}`);
      } else {
        errorMessage = error.message;
        console.error(`❌ Error during API test:`, error.message);
        console.error(`Error name:`, error.name);
        console.error(`Error stack:`, error.stack);
      }
    } else {
      console.error(`❌ Unknown error:`, error);
    }
    
    console.log(`🧪 ========================================\n`);
    
    return {
      success: false,
      message: errorMessage,
      details: error,
    };
  }
}
