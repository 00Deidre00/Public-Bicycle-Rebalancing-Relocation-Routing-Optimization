
import { RouteStep, ParsedRoute } from '@/types/RouteData';

// Calculate distance between two coordinates using Haversine formula
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  return distance;
}

// Parse CSV data into route steps
export function parseRouteData(csvData: string): ParsedRoute {
  const lines = csvData.trim().split('\n');
  const steps: RouteStep[] = [];
  
  // Skip header line
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const parts = line.split(/\s+/);
    if (parts.length < 8) continue;
    
    const step: RouteStep = {
      step: parseInt(parts[0]),
      clusterId: parts[1],
      stationId: parts[2],
      latitude: parseFloat(parts[3]),
      longitude: parseFloat(parts[4]),
      actionAmount: parseInt(parts[5]),
      truckLoadBefore: parseInt(parts[6]),
      truckLoadAfter: parseInt(parts[7]),
    };
    
    steps.push(step);
  }
  
  // Calculate total distance
  let totalDistance = 0;
  for (let i = 0; i < steps.length - 1; i++) {
    const distance = calculateDistance(
      steps[i].latitude,
      steps[i].longitude,
      steps[i + 1].latitude,
      steps[i + 1].longitude
    );
    totalDistance += distance;
  }
  
  // Calculate total redistribution amount (sum of absolute action amounts)
  const redistributionAmount = steps.reduce(
    (sum, step) => sum + Math.abs(step.actionAmount),
    0
  );
  
  // Estimate time (assuming average speed of 15 km/h)
  const estimatedTime = Math.round((totalDistance / 15) * 60);
  
  return {
    steps,
    totalDistance: Math.round(totalDistance * 100) / 100,
    estimatedTime,
    redistributionAmount,
  };
}

// Sample data from the image
export const sampleRouteData = `Step	ClusterID	StationID	Latitude	Longitude	ActionAmount	TruckLoad_Before	TruckLoad_After
0	0	0	37.55065918	126.8497696	0	0	4
1	49	Cluster_49	37.55065918	126.8497696	-11	4	15
2	1	2744	37.56209183	126.8209686	15	15	0
3	31	Cluster_31	37.55363083	126.8286133	-15	0	15
4	83	2732	37.5553093	126.8298569	8	15	7
5	78	1197	37.5602417	126.8358078	3	7	0
5	78	2717	37.56133652	126.8339005	2	7	0
6	3	Cluster_3	37.56808980333333	126.83540598333332	0	0	0
7	30	2715	37.56692505	126.8274384	-14	0	15
7	30	2701	37.56520081	126.8273163	-1	0	15
8	90	Cluster_90	37.56771469	126.8217239	0	15	15
9	70	Cluster_70	37.57312393	126.8223877	0	15	15
10	1	2744	37.56209183	126.8209686	15	15	0
11	72	Cluster_72	37.55939255	126.8194794	0	0	0
12	101	3776	37.5675354	126.8051834	-15	0	15
13	80	1199	37.54782104	126.8361282	14	15	0
13	80	1126	37.54890823	126.8365631	1	15	0`;
