
import { Platform } from 'react-native';

export interface RoutePoint {
  latitude: number;
  longitude: number;
}

export interface RouteSegment {
  points: RoutePoint[];
  distance: number;
  duration: number;
  isRealRoute: boolean;
}

const ORS_API_KEY = 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6ImM4YmRjZGQzMzI2NGE1MWY5YTkwMzhkN2VmOThmN2YxODMyM2U5OTFjMTE2NGJmYWNkMmZlOWMzIiwiaCI6Im11cm11cjY0In0=';

export function decodePolyline(encoded: string): RoutePoint[] {
  const points: RoutePoint[] = [];
  let index = 0;
  const len = encoded.length;
  let lat = 0;
  let lng = 0;

  while (index < len) {
    let b;
    let shift = 0;
    let result = 0;

    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);

    const dlat = (result & 1) !== 0 ? ~(result >> 1) : result >> 1;
    lat += dlat;

    shift = 0;
    result = 0;

    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);

    const dlng = (result & 1) !== 0 ? ~(result >> 1) : result >> 1;
    lng += dlng;

    points.push({
      latitude: lat / 1e5,
      longitude: lng / 1e5,
    });
  }

  return points;
}

export function generateCurvedPath(
  origin: RoutePoint,
  destination: RoutePoint,
  numPoints: number = 20
): RoutePoint[] {
  const points: RoutePoint[] = [];
  
  const midLat = (origin.latitude + destination.latitude) / 2;
  const midLng = (origin.longitude + destination.longitude) / 2;
  
  const dx = destination.longitude - origin.longitude;
  const dy = destination.latitude - origin.latitude;
  const distance = Math.sqrt(dx * dx + dy * dy);
  const offset = distance * 0.1;
  
  const controlLat = midLat - (dx * offset);
  const controlLng = midLng + (dy * offset);
  
  for (let i = 0; i <= numPoints; i++) {
    const t = i / numPoints;
    const t1 = 1 - t;
    
    const lat = t1 * t1 * origin.latitude + 
                2 * t1 * t * controlLat + 
                t * t * destination.latitude;
    
    const lng = t1 * t1 * origin.longitude + 
                2 * t1 * t * controlLng + 
                t * t * destination.longitude;
    
    points.push({ latitude: lat, longitude: lng });
  }
  
  return points;
}

// Calculate distance between two points using Haversine formula
function calculateDistance(point1: RoutePoint, point2: RoutePoint): number {
  const R = 6371000; // Earth's radius in meters
  const dLat = (point2.latitude - point1.latitude) * Math.PI / 180;
  const dLon = (point2.longitude - point1.longitude) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(point1.latitude * Math.PI / 180) * 
    Math.cos(point2.latitude * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Validate coordinates
function validateCoordinates(point: RoutePoint): boolean {
  if (!point || typeof point.latitude !== 'number' || typeof point.longitude !== 'number') {
    console.error('❌ Invalid point object:', point);
    return false;
  }
  
  if (isNaN(point.latitude) || isNaN(point.longitude)) {
    console.error('❌ Coordinates are NaN:', point);
    return false;
  }
  
  if (point.latitude < -90 || point.latitude > 90) {
    console.error('❌ Latitude out of range:', point.latitude);
    return false;
  }
  
  if (point.longitude < -180 || point.longitude > 180) {
    console.error('❌ Longitude out of range:', point.longitude);
    return false;
  }
  
  return true;
}

export async function fetchRouteFromOpenRouteService(
  origin: RoutePoint,
  destination: RoutePoint,
  apiKey: string = ORS_API_KEY
): Promise<RouteSegment | null> {
  if (!apiKey) {
    console.log('❌ No OpenRouteService API key provided');
    return null;
  }

  // Validate coordinates before sending
  console.log('🔍 Validating coordinates...');
  console.log('Origin:', origin);
  console.log('Destination:', destination);
  
  if (!validateCoordinates(origin)) {
    console.error('❌ Invalid origin coordinates');
    return null;
  }
  
  if (!validateCoordinates(destination)) {
    console.error('❌ Invalid destination coordinates');
    return null;
  }

  // Check if points are too close (less than 10 meters)
  const directDistance = calculateDistance(origin, destination);
  if (directDistance < 10) {
    console.log(`⚠️ Points too close (${directDistance.toFixed(1)}m), using direct line`);
    return {
      points: [origin, destination],
      distance: directDistance,
      duration: (directDistance / 1000) / 15 * 3600, // Assume 15 km/h cycling speed
      isRealRoute: false,
    };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    console.log('⏰ Aborting request after 20 seconds');
    controller.abort();
  }, 20000);

  try {
    const url = 'https://api.openrouteservice.org/v2/directions/cycling-regular';
    
    console.log(`\n🚴 ========================================`);
    console.log(`🚴 Fetching ORS route`);
    console.log(`📍 From: (${origin.latitude.toFixed(6)}, ${origin.longitude.toFixed(6)})`);
    console.log(`📍 To: (${destination.latitude.toFixed(6)}, ${destination.longitude.toFixed(6)})`);
    console.log(`📏 Direct distance: ${(directDistance / 1000).toFixed(2)} km`);
    console.log(`🔑 API Key: ${apiKey.substring(0, 20)}...${apiKey.substring(apiKey.length - 10)}`);
    console.log(`🔑 API Key length: ${apiKey.length} characters`);
    console.log(`🌐 URL: ${url}`);
    console.log(`⏱️ Timeout: 20 seconds`);
    
    // IMPORTANT: OpenRouteService expects [longitude, latitude] format
    const requestBody = {
      coordinates: [
        [origin.longitude, origin.latitude],
        [destination.longitude, destination.latitude],
      ],
    };
    
    console.log(`📤 Request body:`, JSON.stringify(requestBody, null, 2));
    console.log(`📤 Coordinate format: [longitude, latitude]`);
    console.log(`📤 First coordinate: [${origin.longitude}, ${origin.latitude}]`);
    console.log(`📤 Second coordinate: [${destination.longitude}, ${destination.latitude}]`);
    
    const startTime = Date.now();
    console.log(`⏰ Request started at: ${new Date(startTime).toISOString()}`);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
        'Content-Type': 'application/json; charset=utf-8',
        'Authorization': apiKey,
      },
      body: JSON.stringify(requestBody),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);
    
    const endTime = Date.now();
    const requestDuration = endTime - startTime;
    console.log(`⏱️ Request completed in ${requestDuration}ms (${(requestDuration / 1000).toFixed(2)}s)`);
    console.log(`📥 Response status: ${response.status} ${response.statusText}`);
    console.log(`📥 Response URL: ${response.url}`);
    console.log(`📥 Response type: ${response.type}`);
    console.log(`📥 Response ok: ${response.ok}`);

    console.log(`📥 Response Headers:`);
    response.headers.forEach((value, key) => {
      console.log(`   ${key}: ${value}`);
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`❌ ORS API error: ${response.status} ${response.statusText}`);
      console.error(`❌ Error response body:`, errorText);
      
      try {
        const errorJson = JSON.parse(errorText);
        console.error(`❌ ORS Error details:`, JSON.stringify(errorJson, null, 2));
        
        if (errorJson.error) {
          console.error(`❌ Error object:`, JSON.stringify(errorJson.error, null, 2));
          if (errorJson.error.message) {
            console.error(`❌ Error message: ${errorJson.error.message}`);
          }
          if (errorJson.error.code) {
            console.error(`❌ Error code: ${errorJson.error.code}`);
          }
        }
      } catch (e) {
        console.error(`❌ Could not parse error as JSON`);
      }
      
      console.log(`🚴 ========================================\n`);
      return null;
    }

    const responseText = await response.text();
    console.log(`📦 Raw response text (first 500 chars):`, responseText.substring(0, 500));
    
    let data;
    try {
      data = JSON.parse(responseText);
    } catch (e) {
      console.error(`❌ Failed to parse response as JSON`);
      console.error(`Response text:`, responseText);
      console.log(`🚴 ========================================\n`);
      return null;
    }
    
    console.log(`📦 ORS Response data received`);
    console.log(`📦 Response keys:`, Object.keys(data).join(', '));
    console.log(`📦 Full response:`, JSON.stringify(data, null, 2));

    if (!data.routes || data.routes.length === 0) {
      console.warn(`⚠️ No routes found from OpenRouteService`);
      console.warn(`Response data:`, JSON.stringify(data, null, 2));
      console.log(`🚴 ========================================\n`);
      return null;
    }

    const route = data.routes[0];
    console.log(`📦 Route object keys:`, Object.keys(route).join(', '));
    console.log(`📦 Full route object:`, JSON.stringify(route, null, 2));
    
    if (!route.geometry) {
      console.error(`❌ No geometry in route`);
      console.error(`Route object:`, JSON.stringify(route, null, 2));
      console.log(`🚴 ========================================\n`);
      return null;
    }

    console.log(`📦 Geometry type:`, typeof route.geometry);
    
    let points: RoutePoint[] = [];
    
    // Check if geometry is a string (encoded polyline) or object with coordinates
    if (typeof route.geometry === 'string') {
      console.log(`📦 Geometry is an ENCODED POLYLINE`);
      console.log(`📦 Polyline length: ${route.geometry.length} characters`);
      console.log(`📦 First 100 chars: ${route.geometry.substring(0, 100)}`);
      console.log(`🔄 Decoding polyline...`);
      
      try {
        points = decodePolyline(route.geometry);
        console.log(`✅ Decoded ${points.length} points from polyline`);
        
        if (points.length > 0) {
          console.log(`📍 First decoded point:`, points[0]);
          console.log(`📍 Last decoded point:`, points[points.length - 1]);
          console.log(`📍 Sample (first 3):`, points.slice(0, 3));
        }
      } catch (error) {
        console.error(`❌ Failed to decode polyline:`, error);
        console.log(`🚴 ========================================\n`);
        return null;
      }
    } else if (typeof route.geometry === 'object') {
      console.log(`📦 Geometry is an OBJECT`);
      console.log(`📦 Geometry keys:`, Object.keys(route.geometry).join(', '));
      console.log(`📦 Full geometry:`, JSON.stringify(route.geometry, null, 2));
      
      if (!route.geometry.coordinates || !Array.isArray(route.geometry.coordinates)) {
        console.error(`❌ Invalid route geometry coordinates`);
        console.error(`Geometry:`, JSON.stringify(route.geometry, null, 2));
        console.error(`Coordinates type:`, typeof route.geometry.coordinates);
        console.error(`Is array:`, Array.isArray(route.geometry.coordinates));
        console.log(`🚴 ========================================\n`);
        return null;
      }
      
      const coordinates = route.geometry.coordinates;
      console.log(`📦 Coordinates array length: ${coordinates.length}`);
      
      if (coordinates.length === 0) {
        console.error(`❌ Coordinates array is empty!`);
        console.error(`This is unusual - API returned route but no points`);
        console.error(`Route summary:`, route.summary);
        console.log(`🚴 ========================================\n`);
        return null;
      }
      
      console.log(`📦 First coordinate:`, coordinates[0]);
      console.log(`📦 Last coordinate:`, coordinates[coordinates.length - 1]);
      console.log(`📦 Sample of first 3 coordinates:`, coordinates.slice(0, 3));

      // Convert coordinates from [longitude, latitude] to {latitude, longitude}
      points = coordinates.map((coord: number[], index: number) => {
        if (!Array.isArray(coord) || coord.length < 2) {
          console.error(`❌ Invalid coordinate at index ${index}:`, coord);
          return null;
        }
        
        const longitude = coord[0];
        const latitude = coord[1];
        
        if (typeof longitude !== 'number' || typeof latitude !== 'number') {
          console.error(`❌ Non-numeric coordinate at index ${index}:`, coord);
          return null;
        }
        
        if (isNaN(longitude) || isNaN(latitude)) {
          console.error(`❌ NaN coordinate at index ${index}:`, coord);
          return null;
        }
        
        return {
          latitude: latitude,
          longitude: longitude,
        };
      }).filter((point): point is RoutePoint => point !== null);

      console.log(`📦 Converted ${points.length} valid points from ${coordinates.length} coordinates`);
    } else {
      console.error(`❌ Unknown geometry type: ${typeof route.geometry}`);
      console.error(`Geometry:`, route.geometry);
      console.log(`🚴 ========================================\n`);
      return null;
    }

    if (points.length === 0) {
      console.error(`❌ No valid points after processing!`);
      console.log(`🚴 ========================================\n`);
      return null;
    }

    const distance = route.summary?.distance || 0;
    const routeDuration = route.summary?.duration || 0;

    console.log(`✅ Got ORS route with ${points.length} points, ${(distance / 1000).toFixed(2)}km, ${(routeDuration / 60).toFixed(1)}min`);
    console.log(`🚴 ========================================\n`);

    return {
      points,
      distance,
      duration: routeDuration,
      isRealRoute: true,
    };
  } catch (error) {
    clearTimeout(timeoutId);
    
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        console.error(`⏰ Request aborted after timeout`);
      } else {
        console.error(`❌ Error fetching route from OpenRouteService:`, error.message);
        console.error(`Error name: ${error.name}`);
        console.error(`Error stack:`, error.stack);
      }
    } else {
      console.error(`❌ Unknown error:`, error);
    }
    
    console.log(`🚴 ========================================\n`);
    return null;
  }
}

export async function fetchActualRoute(
  origin: RoutePoint,
  destination: RoutePoint
): Promise<RouteSegment> {
  console.log(`\n🗺️ Fetching route from (${origin.latitude.toFixed(6)}, ${origin.longitude.toFixed(6)}) to (${destination.latitude.toFixed(6)}, ${destination.longitude.toFixed(6)})`);
  
  const orsRoute = await fetchRouteFromOpenRouteService(origin, destination, ORS_API_KEY);
  if (orsRoute) {
    console.log(`✅ Got route from OpenRouteService`);
    return orsRoute;
  }
  
  console.log(`⚠️ ORS API failed, using STRAIGHT LINE fallback`);
  const points = [origin, destination];
  
  const R = 6371000;
  const dLat = (destination.latitude - origin.latitude) * Math.PI / 180;
  const dLon = (destination.longitude - origin.longitude) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(origin.latitude * Math.PI / 180) * 
    Math.cos(destination.latitude * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  const estimatedDuration = (distance / 1000) / 15 * 3600;
  
  return {
    points,
    distance,
    duration: estimatedDuration,
    isRealRoute: false,
  };
}

export async function fetchRoutesForPath(
  waypoints: RoutePoint[],
  onProgress?: (current: number, total: number) => void
): Promise<RouteSegment[]> {
  const segments: RouteSegment[] = [];
  
  console.log(`\n🗺️ ========================================`);
  console.log(`🗺️ STARTING ROUTE FETCHING PROCESS`);
  console.log(`🗺️ ========================================`);
  console.log(`📊 Total waypoints: ${waypoints.length}`);
  console.log(`📊 Total segments to fetch: ${waypoints.length - 1}`);
  console.log(`🔑 API Key: ${ORS_API_KEY.substring(0, 20)}...${ORS_API_KEY.substring(ORS_API_KEY.length - 10)}`);
  console.log(`🔑 API Key length: ${ORS_API_KEY.length} characters`);
  console.log(`⏱️ Rate limit delay: 2 seconds between requests`);
  
  // Log all waypoints
  console.log(`\n📍 All waypoints:`);
  waypoints.forEach((wp, index) => {
    console.log(`  ${index}: (${wp.latitude.toFixed(6)}, ${wp.longitude.toFixed(6)})`);
  });
  
  console.log(`🗺️ ========================================\n`);
  
  let successCount = 0;
  let failCount = 0;
  const startTime = Date.now();
  
  for (let i = 0; i < waypoints.length - 1; i++) {
    console.log(`\n--- Segment ${i + 1}/${waypoints.length - 1} ---`);
    
    if (onProgress) {
      onProgress(i + 1, waypoints.length - 1);
    }
    
    try {
      const segment = await fetchActualRoute(
        waypoints[i],
        waypoints[i + 1]
      );
      
      segments.push(segment);
      
      if (segment.isRealRoute) {
        successCount++;
        console.log(`✅ Segment ${i + 1}: ORS route with ${segment.points.length} points`);
      } else {
        failCount++;
        console.log(`⚠️ Segment ${i + 1}: Fallback STRAIGHT LINE with ${segment.points.length} points`);
      }
      
      if (i < waypoints.length - 2) {
        console.log(`⏳ Waiting 2 seconds to avoid rate limiting...`);
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    } catch (error) {
      console.error(`❌ Error fetching segment ${i + 1}:`, error);
      failCount++;
      
      const fallbackSegment = await fetchActualRoute(waypoints[i], waypoints[i + 1]);
      segments.push(fallbackSegment);
    }
  }
  
  const endTime = Date.now();
  const totalTime = (endTime - startTime) / 1000;
  const totalDistance = segments.reduce((sum, seg) => sum + seg.distance, 0);
  const totalDuration = segments.reduce((sum, seg) => sum + seg.duration, 0);
  
  console.log(`\n🗺️ ========================================`);
  console.log(`🗺️ ROUTE FETCHING COMPLETE`);
  console.log(`🗺️ ========================================`);
  console.log(`⏱️ Total time: ${totalTime.toFixed(1)} seconds`);
  console.log(`✅ Successful ORS routes: ${successCount}/${waypoints.length - 1}`);
  console.log(`⚠️ Fallback straight lines: ${failCount}/${waypoints.length - 1}`);
  console.log(`📏 Total distance: ${(totalDistance / 1000).toFixed(2)} km`);
  console.log(`⏱️ Total duration: ${(totalDuration / 60).toFixed(0)} minutes`);
  
  if (failCount > 0 && successCount === 0) {
    console.error(`\n❌❌❌ CRITICAL: ALL ROUTES FAILED! ❌❌❌`);
    console.error(`This means the OpenRouteService API is not working at all.`);
    console.error(`\nPossible causes:`);
    console.error(`  1. Invalid API key or API key not activated`);
    console.error(`  2. API key expired or quota exceeded`);
    console.error(`  3. Network/CORS issues blocking requests`);
    console.error(`  4. API endpoint changed or unavailable`);
    console.error(`  5. Firewall or proxy blocking API requests`);
    console.error(`  6. API returning encoded polyline but decoding failed`);
    console.error(`\nTroubleshooting steps:`);
    console.error(`  1. Check your OpenRouteService dashboard: https://openrouteservice.org/dev/#/home`);
    console.error(`  2. Verify API key is active and has quota remaining`);
    console.error(`  3. Test API key with curl or Postman`);
    console.error(`  4. Check network connectivity and proxy settings`);
    console.error(`  5. Review console logs above for detailed error messages`);
    console.error(`❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌\n`);
  } else if (failCount > 0) {
    console.warn(`\n⚠️ Some routes failed (${failCount}/${waypoints.length - 1})`);
    console.warn(`Check console logs above for specific error messages\n`);
  } else {
    console.log(`\n✅ All routes successfully fetched from OpenRouteService!\n`);
  }
  
  console.log(`🗺️ ========================================\n`);
  
  return segments;
}
